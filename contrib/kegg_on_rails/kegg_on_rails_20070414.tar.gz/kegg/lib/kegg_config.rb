require 'bio'
require 'pp'
require 'kconv'

STDERR.puts "kegg_config is loaded..."

module KEGG_CONFIG

  ### load_category

  CATEGORY_DIR = "data/files"

  CATEGORY_FILES = [
    "#{CATEGORY_DIR}/Organism",
    "#{CATEGORY_DIR}/Organism_jp",
    "#{CATEGORY_DIR}/Pathway",
    "#{CATEGORY_DIR}/Pathway_jp",
    "#{CATEGORY_DIR}/KO",
  ]


  ### for enzyme, compound, glycan, drug

  LIGAND_DIR = "data/kegg/ligand"


  ### load_enzyme

  ENZYME_FILE = "#{LIGAND_DIR}/enzyme/enzyme"


  ### load_compound

  COMPOUND_FILE = "#{LIGAND_DIR}/compound/compound"


  ### load_drug
 
  DRUG_FILE = "#{LIGAND_DIR}/drug/drug"


  ### load_glycan

  GLYCAN_FILE = "#{LIGAND_DIR}/glycan/glycan"


  ### load_genome

  GENOME_DIR = "data/kegg/genes"
  GENOME_FILE = "#{GENOME_DIR}/genome"


  ### load_genes

  GENES_DIR = "data/kegg/genes"

  #GENES_FILES = Dir.glob("#{GENES_DIR}/*").sort.reject { |file|
  #                file[/\.(acc|pag|tit)$/]
  #              } - ["organisms.lst"]
  GENES_FILES = [
    "#{GENES_DIR}/organisms/eco/E.coli.ent",
#   "#{GENES_DIR}/organisms/hsa/H.sapiens.ent",
#   "#{GENES_DIR}/organisms/mge/M.genitalium.ent",
#   "#{GENES_DIR}/organisms/pfa/P.falciparum.ent",
#   "#{GENES_DIR}/organisms/sce/S.cerevisiae.ent",
  ]


  ### load_ortholog

  ORTHOLOG_DIR = "data/kegg/genes"
  ORTHOLOG_FILE = "#{ORTHOLOG_DIR}/ko"


  ### load_pathway

  KGML_DIR = "data/kegg/xml/"

  #KGML_ORG_DIRS = Dir.glob("#{KGML_DIR}/*").select {|file| File.directory?}
  KGML_ORG_DIRS = [
    "#{KGML_DIR}/map",
    "#{KGML_DIR}/organisms/eco",
#   "#{KGML_DIR}/organisms/hsa",
#   "#{KGML_DIR}/organisms/mge",
#   "#{KGML_DIR}/organisms/pfa",
#   "#{KGML_DIR}/organisms/sce",
  ]

end

