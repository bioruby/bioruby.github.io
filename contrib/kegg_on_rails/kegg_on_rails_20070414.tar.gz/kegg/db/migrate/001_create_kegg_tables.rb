class CreateKeggTables < ActiveRecord::Migration
  def self.up
    create_table :linkdbs do |t|
      t.column "db1", :string
      t.column "entry1", :string
      t.column "db2", :string
      t.column "entry2", :string
      t.column "link", :string		# "external", "substrate", ...
      t.column "comment", :text		# free text
    end
    add_index :linkdbs, :db1
    add_index :linkdbs, :entry1
    add_index :linkdbs, :db2
    add_index :linkdbs, :entry2
    add_index :linkdbs, :link

    create_table "categories" do |t|	# acts_as_nested_set + tree
      t.column "parent_id", :integer
      t.column "lft", :integer
      t.column "rgt", :integer
      t.column "level", :string		# "root", "Pathway", 1, 2, 3, ...
      t.column "section", :string	# "1.1"
      t.column "definition", :text	# "Carbohydrate Metabolism"
      t.column "target", :string	# "path:map01110", "hsa00001.keg"
      t.column "href", :text		# <a href="/dbget-bin/..."
      t.column "anchor", :text		# <a href=...>"hsa"</a>
      t.column "line", :text
    end
    add_index :categories, :parent_id
    add_index :categories, :lft
    add_index :categories, :rgt
    add_index :categories, :level

    create_table "compounds" do |t|
      t.column "entry", :string		# "C00001"
      t.column "name", :text		# "H2O; Water"
      t.column "formula", :string	# "H2O"
      t.column "mass", :float		# "18.0106"
      t.column "comment", :text
      t.column "kcf", :text
    end
    add_index :compounds, :entry

    create_table "drugs" do |t|
      t.column "entry", :string		# "C00001"
      t.column "name", :text		# "H2O; Water"
      t.column "formula", :string	# "H2O"
      t.column "mass", :float		# "18.0106"
      t.column "activity", :text        # "Pharmaceutic aid [solvent]"
      t.column "remark", :text          # "Same as: C00001\nTherapeutic ..."
      t.column "comment", :text         # "Component of Absorptive ..."
      t.column "kcf", :text
    end
    add_index :drugs, :entry

    create_table "enzymes" do |t|
      t.column "entry", :string		# "1.1.1.1"
      t.column "name", :text		# "alcohol dehydrogenase; ADH; ..."
      t.column "sysname", :text		# "alcohol:NAD+ oxidoreductase"
      t.column "comment", :text
      t.column "reaction", :text	# "an alcohol + NAD+ = an aldehyde..."
      t.column "iubmb_reaction", :text	# "R07327 > R00624; R07326 > R00623..."
      t.column "kegg_reaction", :text	# (other) "R01041 R07105"
    end
    add_index :enzymes, :entry

    create_table "genes" do |t|
      t.column "org", :string		# "eco"
      t.column "entry", :string		# "b0002"
      t.column "molecule", :string	# "CDS", "tRNA", ..
      t.column "name", :string		# "thrA, Hs, thrD, ..."
      t.column "definition", :text	# "bifunctional aspartokinase..."
      t.column "position", :text	# "337..2799"
      t.column "aaseq", :text		# "MRVLKFGGTSVANAERFLRV..."
      t.column "aalen", :integer	# "820"
      t.column "ntseq", :text		# "atgcgagtgttgaagttcgg..."
      t.column "ntlen", :integer	# "2463"
    end
    add_index :genes, :entry

    create_table "genomes" do |t|
      t.column "entry", :string		# "eco"
      t.column "name", :string		# "E.coli, ECOLI, 83333"
      t.column "definition", :text	# "Escherichia coli K-12 MG1655"
      t.column "taxonomy", :string	# "TAX:83333"
      t.column "lineage", :text		# "Bacteria; Proteobacteria; ..."
      t.column "disease", :text		# "Gastric inflammation, peptic ..."
    end
    add_index :genomes, :entry

    create_table "glycans" do |t|
      t.column "entry", :string		# "G00001"
      t.column "name", :string		# "N-Acetyl-D-glucosaminyldiphos..."
      t.column "composition", :string	# "(GlcNAc)1 (PP-Dol)1"
      t.column "mass", :string		# "203.2 (PP-Dol)"
      t.column "keggclass", :string	# "Glycoprotein; N-Glycan"
      t.column "remark", :text
      t.column "comment", :text
      t.column "kcf", :text
    end
    add_index :glycans, :entry

    create_table "graphics" do |t|
      t.column "entry", :integer	# <entry id="1"
      t.column "name", :text		# "hsa:217 hsa:218 hsa:219 ..."
      t.column "category", :string	# <entry type="gene"
      t.column "reaction", :string	# <entry reaction="rn:R00710"
      t.column "link", :string		# <entry link=".../www_bget?hsa+.."
      t.column "fgcolor", :string	# <graphics fgcolor="#000000"
      t.column "bgcolor", :string	# <graphics bgcolor="#000000"
      t.column "shape", :string		# <graphics type="rectangle"
      t.column "x", :integer		# <graphics x="170"
      t.column "y", :integer		# <graphics y="1018"
      t.column "width", :integer	# <graphics width="45"
      t.column "height", :integer	# <graphics height="17"
      t.column "pathway_id", :integer
    end
    add_index :graphics, :entry
    add_index :graphics, :pathway_id

    create_table "orthologs" do |t|
      t.column "entry", :string
      t.column "name", :string
      t.column "definition", :text
    end

    create_table "pathways" do |t|
      t.column "entry", :string		# "hsa00010"
      t.column "org", :string		# "hsa"
      t.column "number", :string	# "00010"
      t.column "title", :text		# "Glycolysis / Gluconeogenesis"
    end
    add_index :pathways, :entry

=begin
    create_table "reactions" do |t|
      t.column "entry", :string
      t.column "name", :text
      t.column "definition", :text
      t.column "equation", :string
      t.column "image", :string
      t.column "comment", :text
      t.column "rpair_id", :integer
      t.add_index "entry"
    end

    create_table "rpairs" do |t|
      t.column "name", :string
    end
=end

  end

  def self.down
    drop_table :linkdbs
    drop_table :categories
    drop_table :compounds
    drop_table :drugs
    drop_table :enzymes
    drop_table :genes
    drop_table :genomes
    drop_table :glycans
    drop_table :graphics
    drop_table :orthologs
    drop_table :pathways
#   drop_table :reactions
#   drop_table :rpairs
  end
end
