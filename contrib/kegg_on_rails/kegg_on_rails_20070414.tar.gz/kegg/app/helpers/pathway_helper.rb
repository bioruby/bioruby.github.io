module PathwayHelper

  def make_shape(graphic)
    case graphic.shape
    when "rectangle", "roundrectangle"
      "rect"
    when "circle"
      "circle"
    end
  end

  def make_coords(graphic)
    x = graphic.x
    y = graphic.y
    w = graphic.width
    h = graphic.height

    coords = ""
    case graphic.shape
    when "rectangle", "roundrectangle"
      case graphic.category
      when "group"
        next
      else # "gene", "enzyme", "map"
        x1 = x - w / 2
        y1 = y - h / 2
        x2 = x1 + w
        y2 = y1 + h
        coords = "#{x1},#{y1},#{x2},#{y2}"
      end
    when "circle"
      radius = w / 2
      coords = "#{x},#{y},#{radius}"
    end
    return coords
  end
  
  def label_title_entry(node)
    section, definition, dbentry = node.section, node.definition, node.target
    if dbentry
      if dbentry[/:/]
        path, entry = dbentry.split(':')
      elsif dbentry[/\.keg/]
        entry = dbentry[/^\D+/]
      end
    else
      entry = dbentry
    end
    if section[/^\d/]
      label = section
    else
      label = entry
    end
    return [label, definition, entry]
  end

  def link_to_pathway(section, definition, dbentry)
    if dbentry
      if dbentry[/:/]
        path, entry = dbentry.split(':')
        if pathway = Pathway.dbentry(dbentry)
          redirect = false
        else
          redirect = true
        end
      elsif dbentry[/\.keg/]
        entry = dbentry[/^\D+/]
      end
    end
    if section[/^\d/]
      label = section
    else
      label = entry
    end
    if dbentry
      if redirect
        org = entry[/\D+/]
        url = "http://www.kegg.jp/kegg/pathway/#{org}/#{entry}.html"
        "#{label} " + link_to(definition, url)
      else
        "#{label} " + link_to(definition, :action => :show, :id => entry)
      end
    else
      "#{label} " + definition
    end
  end

end
