class Linkdb < ActiveRecord::Base
  def self.db2db(db1, db2)
    list = self.find_all_by_db1_and_db2(db1, db2)
    return list.map {|x| "#{x.db1}:#{x.entry1}\t#{x.db2}:#{x.entry2}"}
  end

  def self.targets(dbentry, db2 = nil, link = nil)
    list = []
    db1, entry1 = dbentry.split(':')
    if link
      if db2
        list = self.find_all_by_db1_and_entry1_and_db2_and_link(db1, entry1, db2, link)
      else
        list = self.find_all_by_db1_and_entry1_and_link(db1, entry1, link)
      end
    else
      if db2
        list = self.find_all_by_db1_and_entry1_and_db2(db1, entry1, db2)
      else
        list = self.find_all_by_db1_and_entry1(db1, entry1)
      end
    end
    return list.map {|x| "#{x.db2}:#{x.entry2}"}
  end

  def self.targets_by_db(dbentry, db2)
    targets(dbentry, db2)
  end

  def self.targets_by_link(dbentry, link)
    targets(dbentry, nil, link)
  end

  def self.targets_by_db_and_link(dbentry, db2, link)
    targets(dbentry, db2, link)
  end

  def self.pathways(dbentry)
    targets(dbentry, "path")
  end

  def self.enzymes(dbentry)
    targets(dbentry, "ec")
  end

  def self.reactions(dbentry)
    targets(dbentry, "rn")
  end

  def self.compounds(dbentry)
    targets(dbentry, "cpd")
  end

  def self.glycans(dbentry)
    targets(dbentry, "gl")
  end

  def self.drugs(dbentry)
    targets(dbentry, "dr")
  end

  def self.orthlogs(dbentry)
    targets(dbentry, "ko")
  end

  def self.diseases(dbentry)
    targets(dbentry, "omim")
  end

  def self.structures(dbentry)
    targets(dbentry, "pdb")
  end

  def self.dblinks(dbentry)
    targets_by_link(dbentry, "external")
  end

  def self.genes(dbentry, org = nil)
    if org
      targets(dbentry, org)
    else
      targets_by_link(dbentry, "genes")
    end
  end

  def self.motifs(dbentry, db = nil)
    if db
      targets(dbentry, db)
    else
      targets_by_link(dbentry, "motif")
    end
  end

end
