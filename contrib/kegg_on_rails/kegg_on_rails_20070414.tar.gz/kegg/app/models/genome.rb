class Genome < ActiveRecord::Base
  def self.dbentry(dbentry)
    db, entry = dbentry.split(':')
    self.find_by_entry(entry)
  end

  def dbentry
    "gn:#{self.entry}"
  end
end
