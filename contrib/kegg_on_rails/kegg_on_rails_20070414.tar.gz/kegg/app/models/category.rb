class Category < ActiveRecord::Base
  acts_as_nested_set

  belongs_to :parent, :class_name => name, :foreign_key => "parent_id"

  def self.root(filename = "root")
    self.find_by_level(filename)
  end

  def self.nodes(target)
    Category.find_all_by_target(target)
  end

  def ancestors
    node, nodes = self, []
    nodes << node = node.parent until node.root?
    nodes.pop
=begin
    loop do
      node = node.parent
      if node.root?
        break
      else
        nodes << node
      end
    end
=end
    return nodes
  end
  
  def hierarchy
    ancestors.reverse.map {|x| x.definition}.join(" > ")
  end
end
