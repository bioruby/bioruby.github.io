class Compound < ActiveRecord::Base
  def self.dbentry(dbentry)
    db, entry = dbentry.split(':')
    self.find_by_entry(entry)
  end

  def dbentry
    "cpd:#{self.entry}"
  end

  def image
    "http://www.genome.jp/Fig/compound/#{self.entry}.gif"
    #"/kegg/compounds/gif/#{self.entry}.gif"
  end

  def glycans
    Linkdb.glycans(dbentry)
  end

  def reactions
    Linkdb.reactions(dbentry)
  end

  def pathways
    Linkdb.pathways(dbentry)
  end

  def enzymes
    Linkdb.enzymes(dbentry)
  end

  def dblinks
    Linkdb.dblinks(dbentry)
  end
end
