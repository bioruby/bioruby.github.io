class Enzyme < ActiveRecord::Base
  def self.dbentry(dbentry)
    db, entry = dbentry.split(':')
    self.find_by_entry(entry)
  end

  def dbentry
    "ec:#{self.entry}"
  end

  def compounds
    Linkdb.targets(dbentry, "cpd")
  end

  def substrates
    compounds_by_link("substrate")
  end

  def products
    compounds_by_link("product")
  end

  def cofactors
    compounds_by_link("cofactor")
  end

  def inhibitors
    compounds_by_link("inhibitor")
  end

  def reactions
    Linkdb.reactions(dbentry)
  end

  def pathways
    Linkdb.pathways(dbentry)
  end

  def orthlogs
    Linkdb.orthologs(dbentry)
  end

  def genes(org = nil)
    Linkdb.genes(dbentry, org)
  end

  def diseases
    Linkdb.diseases(dbentry)
  end

  def motifs(db = nil)
    Linkdb.motifs(dbentry, db)
  end

  def structures
    Linkdb.structures(dbentry)
  end

  def dblinks
    Linkdb.dblinks(dbentry)
  end

  private

  def compounds_by_link(link)
    Linkdb.targets(dbentry, "cpd", link)
  end
end
