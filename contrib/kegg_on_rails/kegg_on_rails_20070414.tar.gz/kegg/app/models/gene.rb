class Gene < ActiveRecord::Base
  def self.dbentry(dbentry)
    org, entry = dbentry.split(':')
    self.find_by_org_and_entry(org, entry)
  end

  def dbentry
    "#{self.org}:#{self.entry}"
  end

  def pathways
    Linkdb.pathways(dbentry)
  end

  def orthologs
    Linkdb.orthologs(dbentry)
  end

  def motifs(db = nil)
    Linkdb.motifs(dbentry, db)
  end

  def pfam_motifs
    motifs("pf")
  end

  def prosite_motifs
    motifs("ps")
  end

  def dblinks
    Linkdb.dblinks(dbentry)
  end

end
