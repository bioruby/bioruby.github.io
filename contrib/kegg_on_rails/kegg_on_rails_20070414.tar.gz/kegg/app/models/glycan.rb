class Glycan < ActiveRecord::Base
  def self.dbentry(dbentry)
    db, entry = dbentry.split(':')
    self.find_by_entry(entry)
  end

  def dbentry
    "gl:#{self.entry}"
  end

  def image
    "http://www.genome.jp/Fig/glycan/#{self.entry}.gif"
    # "/Fig/glycan/#{self.entry}.gif"
  end

  def compounds
    Linkdb.compounds(dbentry)
  end

  def reactions
    Linkdb.reactions(dbentry)
  end

  def pathways
    Linkdb.pathways(dbentry)
  end

  def enzymes
    Linkdb.enzymes(dbentry)
  end

  def orthologs
    Linkdb.orthologs(dbentry)
  end

  def dblinks
    Linkdb.dblinks(dbentry)
  end
end
