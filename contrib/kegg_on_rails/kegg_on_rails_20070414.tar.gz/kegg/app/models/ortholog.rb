class Ortholog < ActiveRecord::Base
  def self.dbentry(dbentry)
    db, entry = dbentry.split(':')
    self.find_by_entry(entry)
  end

  def dbentry
    "ko:#{self.entry}"
  end

  def genes(org = nil)
    Linkdb.genes(dbentry, org)
  end

  def pathways
    Linkdb.pathways(dbentry)
  end

  def dblinks
    Linkdb.dblinks(dbentry)
  end
end
