class Graphic < ActiveRecord::Base
  belongs_to :pathway
end
