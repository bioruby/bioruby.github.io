class Pathway < ActiveRecord::Base
  has_many :graphics

  def self.dbentry(dbentry)
    db, entry = dbentry.split(':')
    self.find_by_entry(entry)
  end

  def dbentry
    "path:#{self.entry}"
  end

  def image
    "http://www.genome.jp/kegg/pathway/#{self.org}/#{self.entry}.gif"
    # "/kegg/pathway/#{self.org}/#{self.entry}.gif"
  end

  def link
    "http://www.genome.jp/dbget-bin/show_pathway?#{self.entry}"
    # "/dbget-bin/show_pathway?#{self.entry}"
  end 
end
