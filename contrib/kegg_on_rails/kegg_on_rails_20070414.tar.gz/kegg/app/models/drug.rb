class Drug < ActiveRecord::Base
  def self.dbentry(dbentry)
    db, entry = dbentry.split(':')
    self.find_by_entry(entry)
  end

  def dbentry
    "dr:#{self.entry}"
  end

  def image
    "http://www.genome.jp/Fig/drug/#{self.entry}.gif"
    #"/kegg/drug/gif/#{self.entry}.gif"
  end

  def pathways
    Linkdb.pathways(dbentry)
  end

  def dblinks
    Linkdb.dblinks(dbentry)
  end
end
