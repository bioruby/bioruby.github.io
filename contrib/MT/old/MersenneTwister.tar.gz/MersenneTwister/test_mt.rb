require 'mt'

real=MT.new(4357)

0.upto(100 - 1) do |j|
  printf("%5i\n", real.genrand_dice(6))
end
puts ""

