# This library is free software; you can redistribute it and/or   #
# modify it under the terms of the GNU Library General Public     #
# License as published by the Free Software Foundation; either    #
# version 2 of the License, or (at your option) any later         #
# version.                                                        #
# This library is distributed in the hope that it will be useful, #
# but WITHOUT ANY WARRANTY; without even the implied warranty of  #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.            #
# See the GNU Library General Public License for more details.    #
# You should have received a copy of the GNU Library General      #
# Public License along with this library; if not, write to the    #
# Free Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA   # 
# 02111-1307  USA                                                 #


=begin 

== NAME
 Mersenne Twister for Ruby 
  - A Ruby Class for MT19937 pseudorandom number generator


== REFERENCES                                                       

   M. Matsumoto and T. Nishimura,                                  
   "Mersenne Twister: A 623-Dimensionally Equidistributed Uniform  
   Pseudo-Random Number Generator",                                
   ACM Transactions on Modeling and Computer Simulation,           
   Vol. 8, No. 1, January 1998, pp 3--30.                          

   http://www.math.keio.ac.jp/matumoto/emt.html

== AUTHOR

   Mitsuteru S. Nakao <n@bioruby.org>
   $Id: mt.rb,v 1.1.1.1 2001/10/18 03:26:23 nakao Exp $

== EXAMPLE

  s=MT.new(4357)                       # Set seeds (any 32-bit int)
  
  0.upto(10000 - 1) do |j|
    printf("%i\n", s.genrandi)         # Int
    printf("%5f\n", s.genrandor)       # Reals [0.1)-interval 
    printf("%5f\n", s.genrandcr)       # Reals [0.1]-interval 
    printf("%5f\n", s.dice(6))         # Int [0..5]
  end
  puts ""


=== Class MT

=end

class MT
  # Period parameters #
  N=624
  M=397
  MATRIX_A=0x9908b0df         # constant vector a 
  UPPER_MASK=0x80000000       # most significant w-r bits 
  LOWER_MASK=0x7fffffff       # least significant r bits 

  # Tempering parameters #
  TEMPERING_MASK_B=0x9d2c5680
  TEMPERING_MASK_C=0xefc60000
  def tempering_shift_U(y); (y >> 11);   end
  def tempering_shift_S(y); (y << 7);   end
  def tempering_shift_T(y); (y << 15);   end
  def tempering_shift_L(y); (y >> 18);   end

  def initialize(seed)
    @mt=Array.new # the array for the state vector  
    @mti=N + 1    # mti==N+1 means mt[N] is not initialized 
    sgenrand(seed)
  end

=begin

  setting initial seeds to mt[N] using        
  the generator Line 25 of Table 1 in    
  [KNUTH 1981, The Art of Computer Programming Vol. 2 (2nd Ed.), pp102] 

=end

  def sgenrand(seed)
    0.upto(N - 1) do |i|
      @mt[i]=seed & 0xffff0000
      seed=69069 * seed + 1
      @mt[i] |= (seed & 0xffff0000) >> 16
      seed=69069 * seed + 1
    end
    @mti=N
  end
  private :sgenrand

=begin
  setting initial seeds alternative
=end

  def lsgenrand(seed_array)
    0.upto(N - 1) do |i|
      @mt[i]=seed_array[i]
    end
    @mti=N
  end

=begin
* MT#genrand_int
* MT#genrandi

  Int: 32-bits
=end

  def genrand_int
    y=0
    mag01=[0x0, MATRIX_A]   # @mag01[x] = x * MATRIX_A  for x=0,1 
    if (@mti >= N)
      kk=0

      self.sgenrand(4357) if (@mti == N+1) # a default initial seed is used

      0.upto(N-M - 1) do |kk|
	y=(@mt[kk] & UPPER_MASK).to_i | (@mt[kk+1] & LOWER_MASK).to_i
	@mt[kk]=@mt[kk+M] ^ (y >> 1) ^ mag01[y & 0x1]
      end
      kk.succ.upto(N-1 - 1) do |kk|
	y=(@mt[kk] & UPPER_MASK).to_i | (@mt[kk+1] & LOWER_MASK).to_i
	@mt[kk]=@mt[kk+(M-N)] ^ (y >> 1) ^ mag01[y & 0x1]
      end
      y=(@mt[N-1] & UPPER_MASK).to_i | (@mt[0] & LOWER_MASK).to_i
      @mt[N-1]=@mt[M-1] ^ (y >> 1) ^ mag01[y & 0x1]

      @mti=0
    end
    
    y=@mt[@mti].to_i
    @mti+=1
    y ^= tempering_shift_U(y)
    y ^= tempering_shift_S(y) & TEMPERING_MASK_B
    y ^= tempering_shift_T(y) & TEMPERING_MASK_C 
    y ^= tempering_shift_L(y)

    return  y # Integer
  end
  alias genrandi genrand_int 

=begin
* MT#genrand_closed_reals
* MT#genrandcr
* MT#genrand

  reals: [0,1)-interval
=end

  def genrand_closed_reals
    # reals: [0,1]-interval 
    return ( self.genrand_int.to_f * 2.3283064370807974e-10 ); 
  end
  alias genrandcr genrand_closed_reals

=begin
* MT#genrand_open_reals
* MT#genrandor

  reals: [0,1]-interval
=end

  def genrand_open_reals
    # reals: [0,1)-interval 
    return ( self.genrand_int.to_f * 2.3283064365386963e-10 ); 
  end
  alias genrandor genrand_open_reals

=begin
* MT#genrand_block(max)
* MT#genrand_dice(max)
* MT#dice(max)

  int: [0..max-1]-interval
=end

  def genrand_dice(max)
    return (self.genrand_closed_reals * max).to_i 
  end
  alias dice genrand_dice

end



