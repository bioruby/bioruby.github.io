#include <stdio.h>
#include "mt.h"


/* This main() outputs first 1000 generated numbers.  */
main(void)
{
    int i;
#ifdef hoge
    sgenrand(4357);

    printf ("== genrandc() ==\n");
    for (i=0; i<1000; i++) {
        printf("%10.8f ", genrandc());
        if (i%5==4) printf("\n");
    }

    sgenrand(4357);
    printf ("\n== genrando() ==\n");
    for (i=0; i<1000; i++) {
        printf("%10.8f ", genrando());
        if (i%5==4) printf("\n");
    }

    sgenrand(4357);
    printf ("\n== genrandi() ==\n");
    for (i=0; i<1000; i++) {
        printf("%i ", genrandi());
        if (i%5==4) printf("\n");
    }
#endif
    sgenrand(4357);
    printf ("\n== dice() ==\n");
    for (i=0; i<1000; i++) {
        printf("%i\n", dice(6));
	/*        printf("%i ", dice(6));
		  if (i%5==4) printf("\n"); */
    }
}
