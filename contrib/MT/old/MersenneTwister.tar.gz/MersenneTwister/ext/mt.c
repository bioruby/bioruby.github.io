/* mt.c - Mersenne Twister for Ruby extention               */
/* Mitsuteru S. Nakao <n@bioruby.org>                       */
/* $Id: mt.c,v 1.1 2001/10/18 19:06:57 nakao Exp $ */

#include "ruby.h"
#include "mt.h"

static VALUE 
mt_sgenrand (VALUE self, VALUE seed)
{
  Check_Type(seed, T_FIXNUM);

  seed=FIX2INT(seed);
  sgenrand(seed);
  
  return 0;
}

static VALUE
mt_genrandi (VALUE self)
{
  return INT2NUM(genrandi());
}

static VALUE
mt_genrando (VALUE self)
{
  return rb_float_new(genrando());
}

static VALUE
mt_genrandc (VALUE self)
{
  return rb_float_new(genrandc());
}

static VALUE 
mt_dice (VALUE self, VALUE max)
{
  Check_Type(max, T_FIXNUM);
  max=FIX2INT(max);

  return INT2NUM(dice(max));
}


Init_mt()
{
  
  VALUE cMT=rb_define_class("MT", rb_cObject);
  
  rb_define_method(cMT, "initialize", mt_sgenrand, 1);
  rb_define_method(cMT, "set_seed", mt_sgenrand, 1);

  rb_define_method(cMT, "genrandi", mt_genrandi, 0);
  rb_define_method(cMT, "randint", mt_genrandi, 0);

  rb_define_method(cMT, "genrando", mt_genrando, 0);
  rb_define_method(cMT, "rando", mt_genrando, 0);

  rb_define_method(cMT, "genrandc", mt_genrandc, 0);
  rb_define_method(cMT, "randc", mt_genrandc, 0);

  rb_define_method(cMT, "dice", mt_dice, 1);
}
