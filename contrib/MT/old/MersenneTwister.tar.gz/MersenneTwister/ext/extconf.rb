require 'mkmf'

$LDFLAGS="-L/usr/local/lib -L../"
$CPPFLAGS="-I../"
have_library("mt")
have_header("mt.h")
create_makefile("mt")
