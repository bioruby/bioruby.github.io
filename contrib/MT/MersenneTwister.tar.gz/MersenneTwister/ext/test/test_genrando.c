#include <stdio.h>
#include "mt.h"


/* This main() outputs first 1000 generated numbers.  */
main(void)
{
    int i;
    sgenrand(4357);


    printf ("\n== genrando() ==\n");
    for (i=0; i<1000; i++) {
        printf("%10.8f ", genrando());
        if (i%5==4) printf("\n");
    }

}
