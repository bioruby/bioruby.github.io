require 'mt'
a=Math::RNG::MT19937.new(4357)
puts "\n== MT#dice(6) =="
200.times do
  5.times do
#    print "#{a.genrandi.to_i} "
    print "#{a.genrandi.type} "
#    print printf("%12u", a.genrandi).type
#    printf("%12i ", a.genrandi)
#    print ""
  end
  puts
end

p a.genrandi.type
