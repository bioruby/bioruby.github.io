require '../mt'
a=Math::RNG::MT19937.new(1019033)
puts "\n== MT#dice(6) =="
10000.times do
    printf ("%i ", a.dice(4))
#    printf ("%f", a.rando)
end

