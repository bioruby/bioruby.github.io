require 'mt'
a=Math::RNG::MT19937.new(4357)
puts "\n== MT#genrando =="
200.times do
  5.times do
    printf ("%10.8f ", a.genrando)
  end
  puts
end
