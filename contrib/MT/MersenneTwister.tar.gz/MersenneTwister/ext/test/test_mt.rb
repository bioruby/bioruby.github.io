require 'mt'

puts "hoge"


a=Math::RNG::MT19937.new(4357)

p a

puts "\n== MT#genrandi =="
250.times do
  5.times do
    printf ("%i ", a.genrandi)
  end
  puts ''
end

a=Math::RNG::MT19937.new(4357)
puts "\n== MT#genrandc =="
250.times do
  5.times do
    printf ("%10.8f ", a.genrandc)
  end
  puts ''
end

a=Math::RNG::MT19937.new(4357)
puts "\n== MT#dice(6) =="
250.times do
  4.times do
    printf ("%i ", a.dice(6))
  end
  puts 
end
