/* mt.c - Mersenne Twister for Ruby extention               */
/*        class Math::RNG::MT19937                          */
/* Mitsuteru S. Nakao <n@bioruby.org>                       */
/* $Id: mt.c,v 1.4 2001/10/31 08:36:02 nakao Exp $          */

#include "ruby.h"
#include "mt.h"


static int seed;

static VALUE 
mt_sgenrand (VALUE self, VALUE set_seed)
{
  Check_Type(set_seed, T_FIXNUM);

  seed=FIX2INT(set_seed);
  sgenrand(seed);
  
  return 0;
}

static VALUE
mt_seed (VALUE self) {
  return INT2FIX(seed);
}

static VALUE
mt_genrandi (VALUE self)
{
  return INT2NUM(genrandi());
}

static VALUE
mt_genrando (VALUE self)
{
  return rb_float_new(genrando());
}

static VALUE
mt_genrandc (VALUE self)
{
  return rb_float_new(genrandc());
}

static VALUE 
mt_dice (VALUE self, VALUE max)
{
  Check_Type(max, T_FIXNUM);
  max=FIX2INT(max);

  return INT2NUM(dice(max));
}


Init_mt()
{
  VALUE mMath=rb_define_module("Math");
  VALUE mRNG=rb_define_module_under(mMath, "RNG"); 
  VALUE cMT=rb_define_class_under(mRNG, "MT19937", rb_cObject); 
  
  /* Math::RNG::MT19937.new(seed)      */
  rb_define_method(cMT, "initialize", mt_sgenrand, 1);

  /* Math::RNG::MT19937#set_seed(seed) */
  /* Math::RNG::MT19937#seed=seed      */
  rb_define_method(cMT, "set_seed", mt_sgenrand, 1);
  rb_define_method(cMT, "seed=", mt_sgenrand, 1);
  /* Math::RNG::MT19937#seed           */
  rb_define_method(cMT, "seed", mt_seed, 0);

  /* This method has a bug, Fixnum/Bignum confusion  */
  /* Math::RNG::MT19937#genrandi       */
  /* Math::RNG::MT19937#randint        */
  rb_define_method(cMT, "genrandi", mt_genrandi, 0);
  rb_define_method(cMT, "randint", mt_genrandi, 0);
  rb_define_method(cMT, "genrand_int", mt_genrandi, 0);

  /* [0-1)-interval                    */
  /* Math::RNG::MT19937#genrando       */
  /* Math::RNG::MT19937#rando          */
  rb_define_method(cMT, "genrando", mt_genrando, 0);
  rb_define_method(cMT, "rando", mt_genrando, 0);
  rb_define_method(cMT, "genrand_open_reals", mt_genrando, 0);
  rb_define_method(cMT, "genrandor", mt_genrando, 0);

  /* [0-1]-interval                    */
  /* Math::RNG::MT19937#genrandc       */
  /* Math::RNG::MT19937#randc          */
  rb_define_method(cMT, "genrandc", mt_genrandc, 0);
  rb_define_method(cMT, "randc", mt_genrandc, 0);
  rb_define_method(cMT, "genrand_closed_reals", mt_genrandc, 0);
  rb_define_method(cMT, "genrandcr", mt_genrandc, 0);

  /* [0,block-1]                       */
  /* Math::RNG::MT19937#dice(black)    */
  rb_define_method(cMT, "dice", mt_dice, 1);
  rb_define_method(cMT, "genrand_dice", mt_dice, 1);
  rb_define_method(cMT, "genrand_block", mt_dice, 1);
}
