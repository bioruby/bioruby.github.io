require 'R'

r=R.new

puts r.call("
X11()
a<-sample(100)
a
#postscript('hoge.ps')
plot(a)
plot(a, a)
#dev.off()
")

puts r.call("ls()")

r.cmd("b<-sample(100)")
r.cmd("c<-sample(100)")
r.cmd("postscript()")
r.cmd("plot(a,b,c)")
r.cmd("dev.off()")
r.exec