=begin

== NAME
R.rb  - a interface for R (GNU S)

$Id: R.rb,v 1.1 2001/10/22 08:38:01 nakao Exp $

== EXAMPLE

  r=R.new
  puts r.call("ls()")

  res = r.call("
  a<-sample(10)
  plot(a)
  ")
  print res

  r.cmd("a<-sample(100)")
  r.cmd("postscript()")
  r.cmd("plot(a,1/2)")
  r.cmd("dev.off")
  r.exec


== AUTHOR

Mitsuteru S. Nakao <n@BioRuby.org>



== See also

R (http://www.r-project.org/)


=end

class R

  def initialize (arg='--slave', r_home='/usr/local/lib/R/bin')
    @r_home=r_home
    @r_bin="#{@r_home}/R.bin #{arg}"
    @r_cmd=""
  end
  

  def set_R_HOME=(path)
    @r_home=path
    @r_bin="#{@r_home}/R.bin --slave"
  end
  
  def call(cmd)
    self.exec (cmd)
  end

  def cmd (cmd)
    @r_cmd+=cmd.to_s+"\n"
  end

  def exec(cmd=@r_cmd)
    begin
      @io=IO.popen(@r_bin, "w+")
      @io.sync=1

      @io.puts(cmd)
      @io.close_write

      return @io.read
    ensure
      @io.close
      wait
    rescue
      raise "Error: Cannot open #{@r_bin} \n"
    end
  end

end
