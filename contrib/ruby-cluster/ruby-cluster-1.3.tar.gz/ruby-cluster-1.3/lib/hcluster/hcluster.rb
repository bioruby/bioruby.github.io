# hcluster.rb - hierarchical clustering methods written in C + Ruby
#
# Copyright (C) 2001  OKUJI K. Yoshinori <o@bioruby.org>
#   
# This library is free software; you can redistribute it and/or
# modify it under the terms of the GNU Lesser General Public
# License as published by the Free Software Foundation; either
# version 2 of the License, or (at your option) any later version.
#
# This library is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public
# License along with this library; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

require 'hcluster.so'

module HCluster

  class Tree
    
    def initialize(left, right, relation)
      @left = left
      @right = right
      @relation = relation
      @size = if left.kind_of?(Tree) then left.size else 1 end
      @size += if right.kind_of?(Tree) then right.size else 1 end
    end
    
    attr_reader :left, :right, :size, :relation
    
    def members
      array = if @left.kind_of?(Tree) then @left.members else [@left] end
      array += if @right.kind_of?(Tree) then @right.members else [@right] end
    end
    
    # Ugg.. evil hack.
    def negate
      @relation = -@relation if @relation
      @left.negate if @left.kind_of?(Tree)
      @right.negate if @right.kind_of?(Tree)
    end
    
    SPACE = '  '
    BAR = '| '
    BRANCH = '+-| '
    LEAF = '+- '
    
    def graph(label = nil, dir = :ROOT, header = '')
      append = if dir == :DOWN then BAR else SPACE end
      if @right.kind_of?(Tree)
	@right.graph(label, :UP, header + append)
      else
	print header, append, LEAF,
	  if label then label[@right] else @right end, "\n"
      end
      
      print header, BRANCH, @relation, "\n"
      
      append = if dir == :UP then BAR else SPACE end
      if @left.kind_of?(Tree)
	@left.graph(label, :DOWN, header + append)
      else
	print header, append, LEAF,
	  if label then label[@left] else @left end, "\n"
      end
    end
    
  end
  
end


if $0 == __FILE__
  members = ['c', 'c++', 'obj-c', 'tcl', 'perl', 'python', 'ruby', 'basic']
  rel = HCluster::Relation.new(members.size)
  for i in 0 .. members.size - 2
    for j in i + 1 .. members.size - 1
      rel.set(i, j, (members[i].size - members[j].size).abs)
    end
  end

  print "Single linkage clustering:\n"
  roots = HCluster.scluster(rel)
  roots.each do |member|
    if member.kind_of?(HCluster::Tree)
      member.graph(members)
    else
      print member, "\n"
    end
    
    print "\n"
  end

  print "Complete linkage clustering:\n"
  roots = HCluster.ccluster(rel)
  roots.each do |member|
    if member.kind_of?(HCluster::Tree)
      member.graph(members)
    else
      print member, "\n"
    end
    
    print "\n"
  end
  
  print "Mean linkage clustering:\n"
  roots = HCluster.mcluster(rel)
  roots.each do |member|
    if member.kind_of?(HCluster::Tree)
      member.graph(members)
    else
      print member, "\n"
    end
    
    print "\n"
  end

  # Expression analysis-like.
  print "Mean linkage clustering with large (200) data:\n"
  members = []
  for i in 1..200
    members << 'ORF' + format('%03d', i)
  end

  print 'Generating random numbers...'
  $stdout.flush
  rel = HCluster::Relation.new(members.size)
  for i in 0 .. members.size - 2
    for j in i + 1 .. members.size - 1
      # Generate Pearson correlation-like random numbers.
      rel.set(i, j, rand(0) * 2 - 1)
    end
  end
  print " Done.\n"

  print 'Clustering...'
  $stdout.flush
  roots = HCluster.mcluster(rel, 0.2)
  print " Done.\n"
  roots.each do |member|
    if member.kind_of?(HCluster::Tree)
      member.graph(members)
    else
      print member, "\n"
    end

    print "\n"
  end

  # Sequence analysis-like.
  print "Single linkage clustering with large (1000) data:\n"
  members = []
  for i in 1..1000
    members << 'ORF' + format('%03d', i)
  end

  print 'Generating random numbers...'
  $stdout.flush
  rel = HCluster::Relation.new(members.size)
  for i in 0 .. members.size - 2
    for j in i + 1 .. members.size - 1
      # Generate E-value-like random numbers.
      rel.set(i, j, -rand(0))
    end
  end
  print " Done.\n"

  print 'Clustering...'
  $stdout.flush
  roots = HCluster.scluster(rel, -1.0e-3)
  print " Done.\n"
  roots.each do |member|
    if member.kind_of?(HCluster::Tree)
      member.negate
      member.graph(members)
    else
      print members[member], "\n"
    end

    print "\n"
  end
end
