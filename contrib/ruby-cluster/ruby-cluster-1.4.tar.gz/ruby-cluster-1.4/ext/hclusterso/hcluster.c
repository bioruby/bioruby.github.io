/* hcluster.rb - hierarchical clustering methods written in pure Ruby */
/* Copyright (C) 2001  OKUJI K. Yoshinori <o@bioruby.org>
   
   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307,
   USA. */

#include <ruby.h>
#include <stdio.h>
#include <stdlib.h>

#define DEBUG	0

#define SWAP(i, j)	{ int tmp = j; j = i; i = tmp; }

struct reldata
{
  int size;
  double **rel;
  double fill;
};

struct treedata
{
  VALUE left;
  VALUE right;
  double rel;
  int size;
};

static VALUE mHCluster;
static VALUE cRelation;
static VALUE cTree;
static ID id_new;
static ID id_kind_of;

static void
free_rel (struct reldata *relp)
{
  if (relp->rel)
    xfree (relp->rel);
}

static void
init_rel (struct reldata *relp, int size, double fill)
{
  relp->size = size < 2 ? 0 : size;
  relp->fill = fill;
  relp->rel = 0;
  
  if (relp->size != 0)
    {
      double **p;
      int i;
      int offset;
      int num;

      num = 2 * size - 1;
      
      p = (double **) xmalloc ((num - 1) * sizeof (double *)
			       + num * (num - 1) / 2 * sizeof (double));
      
      for (i = 0; i < num * (num - 1) / 2; i++)
	*((double *) (p + num - 1) + i) = fill;

      for (offset = 0, i = 0; i < num - 1; offset += num - i - 1, i++)
	p[i] = (double *) (p + num - 1) + offset - i - 1;

      relp->rel = p;
    }      
}

static VALUE
Relation_new (int argc, VALUE *argv, VALUE klass)
{
  VALUE vsize;
  VALUE vfill;
  int size;
  double fill;
  struct reldata *relp;
  VALUE obj;
  
  rb_scan_args (argc, argv, "02", &vsize, &vfill);
  
  if (NIL_P (vsize))
    size = 0;
  else
    size = NUM2INT (vsize);

  if (NIL_P (vfill))
    /* minus infinite.  */
    fill = -1.0/0.0;
  else
    fill = NUM2DBL (vfill);

  obj = Data_Make_Struct (klass, struct reldata, 0, free_rel, relp);
  init_rel (relp, size, fill);
  
  return obj;
}

static VALUE
Relation_size (VALUE obj)
{
  struct reldata *relp;

  Data_Get_Struct (obj, struct reldata, relp);
  return INT2NUM (relp->size);
}

static VALUE
Relation_get (VALUE obj, VALUE vi, VALUE vj)
{
  struct reldata *relp;
  int i, j;

  Data_Get_Struct (obj, struct reldata, relp);
  
  i = NUM2INT (vi);
  j = NUM2INT (vj);
  if (i == j || i < 0 || j < 0 || i >= relp->size || j >= relp->size)
    rb_raise (rb_eArgError, "invalid index specified");

  if (i > j)
    SWAP (i, j);
  
  return rb_float_new (relp->rel[i][j]);
}

static VALUE
Relation_set (VALUE obj, VALUE vi, VALUE vj, VALUE vval)
{
  struct reldata *relp;
  int i, j;
  double val;
  
  Data_Get_Struct (obj, struct reldata, relp);

  i = NUM2INT (vi);
  j = NUM2INT (vj);
  
  if (NIL_P (vval))
    val = relp->fill;
  else
    val = NUM2DBL (vval);
  
  if (i == j || i < 0 || j < 0)
    rb_raise (rb_eArgError, "invalid index specified");

  if (i > j)
    SWAP (i, j);

  if (j >= relp->size)
    {
      /* Reconstruct the buffer... Uggh..  */
      struct reldata *new_relp;
      
      new_relp = (struct reldata *) xmalloc (sizeof (struct reldata));
      init_rel (new_relp, j + 1, relp->fill);
      if (relp->size != 0)
	{
	  int k;
	  
	  for (k = 0; k < relp->size - 1; k++)
	    memcpy (new_relp->rel[k], relp->rel[k],
		    (relp->size - k - 1) * sizeof (double));
	}

      xfree (relp->rel);
      relp->rel = new_relp->rel;
      relp->size = new_relp->size;
      xfree (new_relp);
    }

  relp->rel[i][j] = val;
  return Qnil;
}

static VALUE
Relation_clear (VALUE obj, VALUE vi, VALUE vj)
{
  return Relation_set (obj, vi, vj, Qnil);
}

struct tree
{
  int left, right;
  int size;
};

static VALUE
create_tree (int member, double **rel, const struct tree *tree, int size)
{
  VALUE vleft, vright;
  int left, right;
  int offset;
  double tmp;
  
  if (member < size)
    return INT2NUM (member);

  offset = member - size;
  left = tree[offset].left;
  right = tree[offset].right;
  if (left < right)
    tmp = rel[left][right];
  else
    tmp = rel[right][left];
  
  vleft = create_tree (left, rel, tree, size);
  vright = create_tree (right, rel, tree, size);
  return rb_funcall (cTree, id_new, 3,
		     vleft, vright, rb_float_new (tmp));
}

static VALUE
cluster (struct reldata *relp, double threshold,
	 double (*func) (double rel1, double rel2, int size1, int size2))
{
  struct tree *tree;
  int *member;
  int i;
  int num_member;
  int num_tree;
  int size;
  double **rel;
  VALUE ary;

  size = relp->size;
  rel = relp->rel;
  
  tree = (struct tree *) xmalloc (sizeof (struct tree) * (size - 1));
  
  member = (int *) xmalloc (sizeof (int) * size);
  for (i = 0; i < size; i++)
    member[i] = i;

  num_member = size;
  num_tree = 0;

  while (num_member > 1)
    {
      int i1, i2;
      int max_i1 = -1, max_i2;
      int max_m1, max_m2;
      int max_size1, max_size2;
      double max = -1.0 / 0.0;
      int n;

      /* Get the maximum.  */
      for (i1 = 0; i1 < num_member - 1; i1++)
	{
	  int m1;

	  m1 = member[i1];
	  for (i2 = i1 + 1; i2 < num_member; i2++)
	    {
	      int m2;
	      double cur;
	      
	      m2 = member[i2];
	      
	      if (m1 < m2)
		cur = rel[m1][m2];
	      else
		cur = rel[m2][m1];
	      
	      if (cur > max)
		{
		  max = cur;
		  max_i1 = i1;
		  max_i2 = i2;
		}
	    }
	}

#if DEBUG
      printf ("\nnum_member = %d, num_tree = %d, max = %f\n",
	      num_member, num_tree, max);
#endif
      
      if (max < threshold || max_i1 == -1)
	break;

      max_m1 = member[max_i1];
      max_m2 = member[max_i2];
      
      /* Delete the merged entries and insert the new entry.  */
      n = num_tree + size;
      
#if DEBUG
      printf ("new entry = %d\n", n);
#endif
      
      MEMMOVE (member + max_i1, member + max_i1 + 1,
	       int, max_i2 - max_i1 - 1);
      MEMMOVE (member + max_i2 - 1, member + max_i2 + 1,
	       int, num_member - max_i2 - 1);
      num_member--;
      member[num_member - 1] = n;

#if DEBUG
      printf ("the rest are:");
      for (i = 0; i < num_member; i++)
	printf (" %d", member[i]);
      putchar ('\n');
#endif
      
      /* Register the new tree (entry).  */
#if DEBUG
      printf ("merge %d and %d\n", max_m1, max_m2);
#endif
      tree[num_tree].left = max_m1;
      tree[num_tree].right = max_m2;
      
      if (max_m1 < size)
	max_size1 = 1;
      else
	max_size1 = tree[max_m1 - size].size;
      
      tree[num_tree].size = max_size1;
      
      if (max_m2 < size)
	max_size2 = 1;
      else
	max_size2 = tree[max_m2 - size].size;
      
      tree[num_tree].size += max_size2;

      /* Compute the new tree vs. all (but itself).  */
      for (i = 0; i < num_member - 1; i++)
	{
	  int m = member[i];
	  double rel1, rel2;
	  double tmp;
	  
	  if (max_m1 < m)
	    rel1 = rel[max_m1][m];
	  else
	    rel1 = rel[m][max_m1];
	  
	  if (max_m2 < m)
	    rel2 = rel[max_m2][m];
	  else
	    rel2 = rel[m][max_m2];
	  
	  tmp = func (rel1, rel2, max_size1, max_size2);
	  if (n < m)
	    rel[n][m] = tmp;
	  else
	    rel[m][n] = tmp;
	}
      
      num_tree++;
    }

  /* Convert the result to Ruby objects.  */
  ary = rb_ary_new ();
  for (i = 0; i < num_member; i++)
    rb_ary_push (ary, create_tree (member[i], rel, tree, size));

  xfree (tree);
  xfree (member);

  return ary;
}

static double
scluster_cb (double rel1, double rel2, int size1, int size2)
{
  double max;
  if (rel1 < rel2)
    max = rel2;
  else
    max = rel1;

  return max;
}

static VALUE
scluster (int argc, VALUE *argv)
{
  VALUE vrel, vthr;
  double threshold;
  struct reldata *relp;
  
  rb_scan_args (argc, argv, "11", &vrel, &vthr);
  
  if (rb_funcall (vrel, id_kind_of, 1, cRelation) == Qfalse)
    rb_raise (rb_eArgError, "the first argument must be Relation");
  
  if (NIL_P (vthr))
    threshold = -1.0/0.0;
  else
    threshold = NUM2DBL (vthr);

  Data_Get_Struct (vrel, struct reldata, relp);
  
  return cluster (relp, threshold, scluster_cb);
}

static double
ccluster_cb (double rel1, double rel2, int size1, int size2)
{
  double min;
  if (rel1 < rel2)
    min = rel1;
  else
    min = rel2;

  return min;
}

static VALUE
ccluster (int argc, VALUE *argv)
{
  VALUE vrel, vthr;
  double threshold;
  struct reldata *relp;
  
  rb_scan_args (argc, argv, "11", &vrel, &vthr);
  
  if (rb_funcall (vrel, id_kind_of, 1, cRelation) == Qfalse)
    rb_raise (rb_eArgError, "the first argument must be Relation");
  
  if (NIL_P (vthr))
    threshold = -1.0/0.0;
  else
    threshold = NUM2DBL (vthr);

  Data_Get_Struct (vrel, struct reldata, relp);
  
  return cluster (relp, threshold, ccluster_cb);
}

static double
mcluster_cb (double rel1, double rel2, int size1, int size2)
{
  return (rel1 * size1 + rel2 * size2) / (size1 + size2);
}

static VALUE
mcluster (int argc, VALUE *argv)
{
  VALUE vrel, vthr;
  double threshold;
  struct reldata *relp;
  
  rb_scan_args (argc, argv, "11", &vrel, &vthr);
  
  if (rb_funcall (vrel, id_kind_of, 1, cRelation) == Qfalse)
    rb_raise (rb_eArgError, "the first argument must be Relation");
  
  if (NIL_P (vthr))
    threshold = -1.0/0.0;
  else
    threshold = NUM2DBL (vthr);

  Data_Get_Struct (vrel, struct reldata, relp);
  
  return cluster (relp, threshold, mcluster_cb);
}

void
Init_hcluster (void)
{
  mHCluster = rb_define_module ("HCluster");
  
  cRelation = rb_define_class_under (mHCluster, "Relation", rb_cObject);
  rb_define_singleton_method (cRelation, "new", Relation_new, -1);
  rb_define_method (cRelation, "size", Relation_size, 0);
  rb_define_method (cRelation, "get", Relation_get, 2);
  rb_define_method (cRelation, "set", Relation_set, 3);
  rb_define_method (cRelation, "clear", Relation_clear, 2);

  /* Dummy. If I knew a method to obtain a class object by name in C...  */
  cTree = rb_define_class_under (mHCluster, "Tree", rb_cObject);
  
  rb_define_module_function (mHCluster, "scluster", scluster, -1);
  rb_define_module_function (mHCluster, "ccluster", ccluster, -1);
  rb_define_module_function (mHCluster, "mcluster", mcluster, -1);

  id_new = rb_intern ("new");
  id_kind_of = rb_intern ("kind_of?");
}
