require 'mkmf'
create_makefile('hcluster')
