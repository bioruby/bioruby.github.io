NaturalBondOrder = {:C => 4, :H => 1, :O => 2, :N => 3, :Mg => 2, :P => 5, :S => 2, :Cl => 1, :Fe => 0,
  :R => 4, :* => 4}
