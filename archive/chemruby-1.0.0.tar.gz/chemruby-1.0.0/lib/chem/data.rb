require 'chem/data/periodic_table'
require 'chem/data/atomic_weight'
require 'chem/data/electronegativity'
require 'chem/data/character'
