#
# chem/db/pubchem.rb - PubChem database class
#
#   Copyright (C) 2005 KADOWAKI Tadashi <kado@kuicr.kyoto-u.ac.jp>
#                      TANAKA   Nobuya  <tanaka@kuicr.kyoto-u.ac.jp>
#
#

require 'uri'
require 'net/http'

module Chem

  module Molecule
    def search_pubchem
    end
  end

  module PubChem

    Host="pubchem.ncbi.nlm.nih.gov"
    Summary="/summary/summary.cgi"

    class PubChem
      Searchpath="/search/"
      Query="PreQSrv.cgi"
      Boundary="-----boundary-----"

      Data = [
        Boundary, "Content-Disposition: form-data; name=\"mode\"", "", "simplequery",
        Boundary, "Content-Disposition: form-data; name=\"check\"", "", "remote",
        Boundary, "Content-Disposition: form-data; name=\"execution\"", "", "remote",
        Boundary, "Content-Disposition: form-data; name=\"queue\"", "", "ssquery",
        Boundary, "Content-Disposition: form-data; name=\"simple_searchdata\"", "", '%s',
        Boundary, "Content-Disposition: form-data; name=\"simple_cid\"", "", "",
        Boundary, "Content-Disposition: form-data; name=\"simple_sid\"", "", "",
        Boundary, "Content-Disposition: form-data; name=\"file\"; filename=\"\"",
        "Content-Type: application/octet-stream", "", "",
        Boundary, "Content-Disposition: form-data; name=\"simple_searchtype\"", "", "fs",
        Boundary, "Content-Disposition: form-data; name=\"maxhits\"", "", '%s',
        Boundary].join("\x0d\x0a")

      def self.smiles_search(smiles, maxhits=100)
        cid = []
        url = ""
        body = ""
        Net::HTTP.version_1_2
        Net::HTTP.start(Host, 80) do |http|
          body = http.post(Searchpath + Query, Data % [smiles, maxhits],
                           {'Content-Type' => "multipart/form-data; boundary=#{Boundary}",
                             'Referer' => "http://pubchem.ncbi.nlm.nih.gov/search/"}).body
          if m = /url="([^"]+)"/.match(body)
            body = http.get(Searchpath + m[1]).body
          end
          while /setTimeout\('document.location.replace\("([^"]+)"\);', (\d+)\)/ =~ body do
            sleep($2.to_f/100)
            response = http.get(URI.parse($1))
            body = response.body
            url = response['location']
          end
          if /PubChem structure search report:(\s|\S)+No hits/ !~ body
            # text format
            url.sub!(/cmd=Select\+from\+History/, 'cmd=Text&dopt=Brief')
            body = http.get(url).body
            body.scan(/\d+: CID: (\d+)/).each do |id|
              cid.push(PubChemEntry.new(id[0].to_i))
            end
            #           # html format
            #           body = http.get(url).body
            #           while /CID: <a href=\"([^"]+)\">(\d+)<\/a>/ =~ body do
            #            cid.push($2)
            #            body = $'
            #           end
          end
        end
        cid
      end

    end

    class PubChemEntry

      def initialize cid
        @cid = cid
      end

      def get_xml
        Net::HTTP.version_1_2
        Net::HTTP.get(Host, Summary + "\?disopt=DisplayXML&cid=%dd" % @cid)
      end

      def get_sdf
        Net::HTTP.version_1_2
        Net::HTTP.get(Host, Summary + "\?disopt=DisplaySDF&cid=%d" % @cid)
      end

    end
  end

end

if $0 == __FILE__
  smiles="CC23(CCC1c4ccc(O)cc4(CCC1C3(CC(O)C2(O))))"
  puts "===== CID(s) for SMILES, #{smiles} ====="
  cid = Chem::PubChem.smiles_search(smiles)
  p cid
  puts "===== MOL format data ===="
  cid.each do |c|
    puts c.get_sdf
  end
#  p Chem::PubChem.get_xml(cid[0])
#  puts Chem::PubChem.get_xml(cid[0]).sdf2mol.data
end
