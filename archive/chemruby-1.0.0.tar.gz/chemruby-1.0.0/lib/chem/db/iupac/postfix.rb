
$reg_postfix = /(ane|anol)/
