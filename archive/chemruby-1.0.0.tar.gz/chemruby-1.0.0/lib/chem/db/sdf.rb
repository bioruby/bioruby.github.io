

module Chem

  module MDL

    class SdfParser
      include Enumerable

      def initialize file
        require 'chem/db/mdl'
        @input = open(file)
      end

      def each
        @input.rewind

        # for \r\n and \n
        first_entry = true
        from = 0
        @input.each("$$$$") do |entry|
          from = entry.index("\n") + 1unless first_entry
          first_entry = false
          next if entry[from..-1].length < 3
          yield MdlMolecule.parse_io(StringIO.new(entry[from..-1]))
        end

      end

      def self.parse file
        SdfParser.new(file)
      end

    end
    
  end
end
