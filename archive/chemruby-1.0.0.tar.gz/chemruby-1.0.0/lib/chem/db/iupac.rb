
require 'chem/db/iupac/a_1'
require 'chem/db/iupac/postfix'
require 'chem/db/iupac/iuparser'

