# = KEGG Compound Function Glycan parser
# Not implemented

module Chem

  module KEGG

    class KCFGlycan

      def initialize filename
        #       filename.each do |line|
        #         puts line
        #       end
      end

    end
  end

end
