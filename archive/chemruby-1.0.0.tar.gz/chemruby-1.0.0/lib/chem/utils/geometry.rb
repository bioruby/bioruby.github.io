
module Chem

  module Molecule

    # Automatically assigns 2-dimensional geometry
    # This method may implicitly called from ChemRuby
    # if nil is assigned to Atom#x
    def assign_2d_geometry
      geometrical_type(nodes[0])
    end

    private
    # 
    def geometrical_type atom
#       adj = adjacent_to(atom)
#       case adj.length
#       when 1
#       when 2
#       when 3
#       when 4
#       end
    end

  end

end
