#
# = chem/utils/subgraph.rb - Subgraph isomorphism
#
# Author::	Nobuya Tanaka <tanaka@chemruby.org>
#		
# Copyright::	Copyright (c) 2001, 2005 ChemRuby project
#
# $Id: ullmann.rb 139 2006-02-07 07:39:20Z tanaka $
#

require 'subcomp'

$ARC = 4 # for 32-bit computer

module Graph

  def adj_matrix
    n_long = (nodes.length - 1) / 32 + 1
    mat = Array.new(n_long * @nodes.length, 0)
    nodes.each_with_index do |node, idx|
      adjacent_to(node).each do |bond, node|
        keta = nodes.index(node) / 32
        mat[idx * n_long + keta] += 1 << (nodes.index(node) - keta * 32)
      end
    end
    mat.pack("L*")
  end

  def match_by_adj_mat mat, len
    m = Array.new("0xff", 100).pack("c*")
    subcomp_match_by_ullmann(mat, len, self.adjacency_list, self.nodes.length, m)
  end

  def match_by_ullmann other, &block
    if other.nodes.length == 1
      self.nodes.find{|node| node.element == other.nodes[0].element}
    end
    subcomp_match_by_ullmann(adj_matrix, nodes.length, other.adjacency_list, other.nodes.length, other.matchable(self, &block))
  end
  alias match match_by_ullmann

  # returns match correspondences without duplicate
  def match_exhaustively other
    correspond = {}
    result = []
    while true
      match = self.match_by_ullmann(other) do |a, b|
        a.element == b.element and not (correspond[a] and correspond[a].include? b)
      end
      break if not match
      result.push(match)
      match.each_with_index do |n, m|
        (correspond[other.nodes[n]] ||=[]).push @nodes[m]
      end
    end
    result
  end

  def matchable other, exlucde = {}
    n_long = (other.nodes.length - 1) / 32 + 1
    mat = Array.new(n_long * @nodes.length, 0)
    @nodes.each_with_index do |node, index|
      other.nodes.each_with_index do |n, idx|
        if node.element == n.element
          keta = idx / 32
          mat[index * n_long + keta] += 1 << (idx - keta * 32)
        end
      end
    end
    mat.pack("L*")
  end

  #obsolete
  def matchable_old other, exlucde = {}
    n_long = (other.nodes.length - 1) / 32 + 1
    row_unit = n_long * ( 32 / 8)
    r = "\0" * 10000
    if block_given?
      @nodes.each_with_index do |node, index|
        other.nodes.each_with_index do |o_node, idx|
          if yield(node, o_node)
            col_byte = idx / 8
            col_bit  = idx - col_byte * 8
            r[index * row_unit + col_byte] += (1 << col_bit)
          end
        end
      end
    else
      @nodes.each_with_index do |node, index|
        other.nodes.each_with_index do |o_node, idx|
          if node.element == o_node.element or node.element == :R or o_node.element == :R
            col_byte = idx / 8
            col_bit  = idx - col_byte * 8
            r[index * row_unit + col_byte] += (1 << col_bit)
          end
        end
      end
    end
    r
  end

  def adjacency_list
    ret = []
    @nodes.each do |node|
      r = []
      self.adjacent_to(node).each do |bond, to|
        r << @nodes.index(to)
      end
      ret << r
    end
    ret
  end

  # Obsolete!?
  def connection
    self_adj = []
    @nodes.each do |node|
      i = 0
      self.adjacent_to(node).each do |bond, to|
        i += 1<< @nodes.index(to)
      end
      self_adj << i
    end
    self_adj
  end

end

module Chem
  module Molecule
    include Graph
  end
end

