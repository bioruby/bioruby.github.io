
require 'chem'
require 'dbm'

module Graph

  class SubGraphDB

    # Create Database object
    # @idx  : index database for @mat and @typ
    #         also stores number of nodes.
    # @mat  : adjacency matrix database
    # @typ  : node type database
    # @dbm  : property database
    def initialize dbname, mode = "w"
      @dbm = DBM.open("#{dbname}.dbm")
      @idx = open("#{dbname}.idx", mode)
      @mat = open("#{dbname}.mat", mode)
      @typ = open("#{dbname}.typ", mode)
    end

    def self.open dbname, mode = "r"
      if mode == "r"
        SubGraphDB.new(dbname, mode)
      else
        self.new(dbname, mode)
      end
    end

    def []= key, mol
      adj = mol.adj_matrix
      @idx.print [mol.nodes.length, @mat.tell, adj.length].pack("i*")
      @mat.print adj
      @typ.print mol.nodes.inject([]){ |ret, node| ret.push(node.atomic_number)}.pack("i*")
    end

    # Closes database
    def close
      @dbm.close
      @idx.close
      @mat.close
      @typ.close
    end

    # Searches molecule from database
    # Example:
    # db = SubGraphDB.open("somewhere/dbname")
    # db.search(SMILES("CCCC"))
    def search mol
      @idx.rewind
      i = 1
      until @idx.eof?
        n_nodes, mat, len_matrix = @idx.read(4 * 3).unpack("i*")
        m = [0xff].pack("c") * 100
        open("test.bin", "w").puts m

        matrix = read_mat(mat, len_matrix)
        #SubGraphDB.show(m, mol.nodes.length, n_nodes)
        if SubGraphDB.match(matrix, n_nodes, mol.adjacency_list, mol.nodes.length, m)
          puts "C%05d" % i
        end
        i += 1
      end
    end

    private
    def read_mat idx, len_matrix
      @mat.seek(idx)
      @mat.read(len_matrix)
    end

  end

end

__END__
require 'chem/utils/subgraph/subcomp'

module Chem
  def self.open_db db_name
    GraphDB.new(db_name)
  end
end

class GraphDB

#   def self.open db_name
#     self.new(db_name)
#   end

#   def initialize db_name, mode="w"
#     if mode == "a"
#       @idx = File.open("#{db_name}.idx", "r+")
#     else
#       @idx = File.open("#{db_name}.idx", mode)
#     end
#     @typ = File.open("#{db_name}.typ", mode)
#     @dat = File.open("#{db_name}.dat", mode)
#     @num = File.open("#{db_name}.num", mode)
#     @typ.print("NodeType ISAM")
#     @dat.print("Adjacency ISAM")
#   end

  def insert mol
    n_bytes = mol.nodes.length / ($ARC * 8.0)

#     @typ.flush
#     @dat.flush
#     @idx.flush

#     record_num = @idx.tell
#     @idx.print [@typ.tell, @dat.tell].pack("ii")

#     @typ.print [mol.nodes.length, mol.edges.length].pack("ii")
#     @dat.print [n_bytes.ceil].pack("i")

#     @typ.print mol.nodes.collect { |node|
#        Chem::Element2Number[node.element]
#     }.pack("i*")

#     mol.nodes.each do |k|
#       atom_type = mol.atoms[k].setup_graph(i)
#       @typ.print [atom_type].pack("i")
#     end


#     @dat.print [n_bytes.ceil].pack("i")
#     j = 0
#     mol.atoms.keys.sort.each do |k|
#       0.upto(n_bytes.ceil - 1) do |o|
#         i = 0
#         mol.atoms[k].set_neighbor
#         0.upto($ARC * 8 - 1) do |m|
#           i += mol.atoms[k].neighbor.include?(mol.atoms[m + 8 * $ARC * o + 1]) ? 2**m : 0
#         end
#         @dat.print [i].pack("L")
#       end
#       j += 1
#     end
#     #p mol.adjacency_list
#     mol.connection.each do |c|
#       puts "%040b" % c
#     end
    #record_num
  end
end
