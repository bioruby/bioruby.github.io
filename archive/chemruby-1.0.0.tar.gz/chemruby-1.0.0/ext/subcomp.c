/**********************************************************************

  subcomp.c -

  $Author: nobyt $

  Copyright (C) 2004-2006 Nobuya Tanaka

**********************************************************************/

#define FULL 0xffffffff
#define ZERO 0x0

#define FAIL 0;
#define SUCCESS 1;

#include <ruby.h>

static void
show(long *m, int pa, int pb)
{
  int i, j, k;
  static int count = 0;
  int n_words;

  n_words = (pb - 1) / (sizeof(int) * 8) + 1;

  //printf("count : %3d\n", count++);

  printf("\n  ");
  for(i = 0 ; i < pb ; i++){
    printf("%d", i % 10);
  }
  printf("\n");
  for(i = 0 ; i < pa * n_words ; i += n_words){
    printf("%d ", (i / n_words) % 10);
    for(k = 0 ; k < n_words ; k++){
      for(j = k * 32 ; j < ((k + 1) * 32 < pb ? (k + 1) * 32 : pb) ; j++){
	if(m[i + k ] & (1 << (j - k * 32)))
	  printf("@");
	else
	  printf(".");
      }
      //printf(" ");
    }
    printf("\n");
  }
  printf("\n");
}

/*
 *  call-seq:
 *     SubGraphDB.show  -> print out adjacency matrix
 *
 *  This function is mainly for debug.
 */

static VALUE
subcomp_show(VALUE self, VALUE str, VALUE pa, VALUE pb)
{
  printf("subcomp_show called %3d %3d\n", FIX2INT(pa), FIX2INT(pb));
  show((long * )RSTRING(str)->ptr, FIX2INT(pa), FIX2INT(pb));
  return Qnil;
}


/*
 * returns number of trailing zero of m-bit
 */
static int ntz_m(long *y, int pb){
  int i = 0;
  int n;
  long x;

  n = 1;

  while(i < pb && y[i] == 0){
    n += 32;
    i++;
  }

  x = y[i];

  if((x & 0x0000FFFF) == 0) {n = n + 16 ; x = x >> 16;}
  if((x & 0x000000FF) == 0) {n = n +  8 ; x = x >>  8;}
  if((x & 0x0000000F) == 0) {n = n +  4 ; x = x >>  4;}
  if((x & 0x00000003) == 0) {n = n +  2 ; x = x >>  2;}
  return n - (x & 1);
}

static int ntz(long x){
  int n;

  if (x == 0) return (32);
  n = 1;
  if((x & 0x0000FFFF) == 0) {n = n + 16 ; x = x >> 16;}
  if((x & 0x000000FF) == 0) {n = n +  8 ; x = x >>  8;}
  if((x & 0x0000000F) == 0) {n = n +  4 ; x = x >>  4;}
  if((x & 0x00000003) == 0) {n = n +  2 ; x = x >>  2;}
  return n - (x & 1);
}

static int ntz_n_words(long * x, int n_words){
  int i;
  int words = 0;
  for(i = 0 ; x[i] == 0 && i < n_words ; i++){
    words += 32;
  }
  return ntz(x[i]) + words;
}

long bit_mask[32] = {
  0x1, 0x2, 0x4, 0x8,
  0x10, 0x20, 0x40, 0x80,
  0x100, 0x200, 0x400, 0x800,
  0x1000, 0x2000, 0x4000, 0x8000,
  0x10000, 0x20000, 0x40000, 0x80000,
  0x100000, 0x200000, 0x400000, 0x800000,
  0x1000000, 0x2000000, 0x4000000, 0x8000000,
  0x10000000, 0x20000000, 0x40000000, 0x80000000,
};

long reverse_bit[32] = {
  0xfffffffe,
  0xfffffffd,
  0xfffffffb,
  0xfffffff7,
  0xffffffef,
  0xffffffdf,
  0xffffffbf,
  0xffffff7f,
  0xfffffeff,
  0xfffffdff,
  0xfffffbff,
  0xfffff7ff,
  0xffffefff,
  0xffffdfff,
  0xffffbfff,
  0xffff7fff,
  0xfffeffff,
  0xfffdffff,
  0xfffbffff,
  0xfff7ffff,
  0xffefffff,
  0xffdfffff,
  0xffbfffff,
  0xff7fffff,
  0xfeffffff,
  0xfdffffff,
  0xfbffffff,
  0xf7ffffff,
  0xefffffff,
  0xdfffffff,
  0xbfffffff,
  0x7fffffff,
};

//int matchN(ADJACENCY *adj_ptr, long *b, long *m, int pa, int pb)
static int matchN(const int * num_adj, long ** point, long *b, long *m, int pa, int pb)
{
  long * mm;// current matrix
  long f[1000];//which columns has been used at an intermediate state of computing
  long h[100];// pb < 100 * 32

  int d;// depth for matrix
  int k;// width for matrix
  int dd;// depth of matrix in refinement step
  int kk;// width of matrix in refinement step

  int i, j;//temp
  long l;// temp

  short vflag;//valid check flag
  int n_words;// number of words needed for storing 'pb' bits.
  long refine_mm;// pointer for mm(match matrix) used in refinment step.

  d = k = 0;
  // start back track
  for(i = 0 ; i < (pb / 32 + 1) ; i++)
    h[i] = 0;
  for(i = 0 ; i < 10 ; i++)
    f[i] = 0;

  n_words = (pb - 1) / (sizeof(int) * 8) + 1;

/*   show(b, pb, pb); */
/*   show(m, pa, pb); */

    if( d == 0 && k == 0){
      k = ntz_n_words(m, n_words);
      h[k / 32] |= bit_mask[k - (k / 32) * 32];//add bit
    }
  while(k <= pb && d <= pa){
/*     printf("d : %3d     k : %3d  n_words : %3d\n", d, k, n_words); */
    if(d < 0){
      printf("d < 0 return \n");
      return FAIL;
    }

    // Idea for optimization :
    // instead of using following equation, just (mm = mm + len) and (mm = mm - len).
    mm = m + pa * (d + 1) * n_words;
/*     printf("pa : %d  d : %d  k : %d  n_words : %d  hint : %d\n", pa, d, k, n_words, pa * (d + 1) * n_words); */

    //printf("ntz : %d\n", ntz(mm));
    //k = ntz(mm + d);
    // set (k, d) bit '1', clear k-column and d-row '0'
/*     printf("k : %d   d: %d\n", k, d); */
    for(j = 0 ; j < n_words ; j++){
      if(j == (k / 32)){
	for(i = 0 ; i < pa ; i++){
	  mm[i * n_words + j] = mm[(i - pa) * n_words + j] & reverse_bit[k - (k / 32) * 32];
	}
	mm[d * n_words + j] = bit_mask[k - (k / 32) * 32];
      }else{
	for(i = 0 ; i < pa ; i++){
	  mm[i * n_words + j] = mm[(i - pa) * n_words + j];
	}
	mm[d * n_words + j] = ZERO;
      }
    }
    // BEGIN
/*     show(mm, pa, pb); */
    // END

    // Refinement step
    // Hot Spot!!
    dd = kk = 0;
/*     printf("before refinement step \n"); */
/*     show(mm, pa, pb); */

    while(dd != pa){
      while(kk != pb){
	//Idea for optimization :
	//refine_mm should not updated 1 / 32 times.mm[dd + ((kk - 1) / 32)]

	//Idea for optimization :
	// when mm is sparse there may be better algorithm
	// for searching '1' bit.
	if(mm[dd * n_words + ((kk - 1) / 32)] & bit_mask[kk - ((kk - 1) / 32) * 32]){
	  // Following loop can be flattened
	  for(i = 0 ; i < num_adj[dd] ; i++){
	    l = 0;
	    for(j = 0 ; j < n_words ; j++){
	      l |= (b[kk * n_words + j] & mm[point[dd][i] * n_words + j]);
	    }
	    if(l == 0){
	      mm[dd * n_words + (kk / 32)] &= reverse_bit[kk - (kk / 32) * 32];//remove bit
/* 	      break;//quit for loop */
	    }
	  }

	}
	kk++;
      }
      // Idea for optimization
      // every 32 bit is tested here.
      kk = 0;
      dd++;
    }
/*     show(mm, pa, pb); */

    //Checking whether match matrices are valid.
    // Subgraph isomorphism can be checked here before reaching d == pa.
    vflag = SUCCESS;
    for(i = 0 ; i < pa ; i++){
      l = 0;
      for(j = 0 ; j < n_words ; j++){
	l |= mm[i * n_words + j];
      }
      if(l == 0){
	vflag = FAIL;
	break;
      }
    }

    if(vflag){// Success
      f[d] = k;
      k = 0;
      while(h[k / 32] & bit_mask[k - (k / 32) * 32])
	k++;
      d++;
      if(d == pa){
/* 	show(mm, pa, pb); */
	//printf("FOUND!  d : %d\n", d);
	return SUCCESS;
      }
      else{
	h[k / 32] |= bit_mask[k - (k / 32) * 32];//add bit
      }
    }else{//Failed
      h[k / 32] &= reverse_bit[k - (k / 32) * 32];//remove bit
      k++;
      //printf("d : %d k : %d\n", d, k);
      while((h[k / 32] & bit_mask[k - (k / 32) * 32] ||
	     (m[d * n_words + (k / 32)] & bit_mask[k - (k / 32) * 32] ) == 0) &&
	    k < pb)
	k++;
/*       printf("d : %d k : %d\n", d, k); */
      while(k > pb){
	if(d == 0){
	  return FAIL;
	}
	d--;
	k = f[d];
	h[k / 32] &= reverse_bit[k - (k / 32) * 32];//remove bit
	k++;
	while(h[k / 32] & bit_mask[k - (k / 32) * 32])
	  k++;
      }
      h[k / 32] |= bit_mask[k - (k / 32) * 32];//add bit
    }
  }
  //printf("d : %d k : %d FAIL!\n", d, k);
  return FAIL;
}

static void set_adjacency(int * num_adj, long ** point, long * adj, VALUE ret){
  int i, j, n_words;
  int off_set = 0;

  n_words = (RARRAY(ret)->len - 1) / (sizeof(int) * 8) + 1;

  for(i = 0 ; i < RARRAY(ret)->len ; i++){
    num_adj[i] = FIX2INT(rb_funcall(RARRAY(ret)->ptr[i], rb_intern("length"), 0));
    point[i] = adj + off_set;
    for(j = 0 ; j < RARRAY(RARRAY(ret)->ptr[i])->len ; j++){
      adj[off_set++] = FIX2INT(RARRAY(RARRAY(ret)->ptr[i])->ptr[j]);
      //printf(" %d ", FIX2INT(RARRAY(RARRAY(ret)->ptr[i])->ptr[j]));
    }
    //printf("\n");
  }
}

static VALUE subcomp_match_by_ullmann(VALUE self, VALUE a_matrix, VALUE pa, VALUE other_adj, VALUE pb, VALUE match){
  // variables for adjacency list of graph A
  int num_adj[1000];
  long * point[1000];
  long adj[3000];//adjacency list

  // match matrix; = pa * (n_words * pa)
  long * mm;//[800000];
  long * m;

  //temporary variables
  int i;
  int result;
  VALUE mapping;

  int n_pb, n_pa;
  int n_words;
  int sizeof_mm;

  n_pb = NUM2INT(pb);
  n_pa = NUM2INT(pa);
  
  if(n_pb > n_pa){
    return Qfalse;
  }

  sizeof_mm = n_pa * (n_pb + 1) * n_words;

  n_words = (n_pa - 1) / (sizeof(int) * 8) + 1;

  mm = (long * )malloc(sizeof(long) * 800000);
  if(RSTRING(match)->len > 800000 * sizeof(long))
    rb_raise(rb_eArgError, "Length of match matrix too short! %d", sizeof(mm));
  
  memcpy(mm, (long *)RSTRING(match)->ptr, RSTRING(match)->len); // BUG!!

  Check_Type(a_matrix, T_STRING);

  set_adjacency(num_adj, point, adj, other_adj);

  //show(mm, n_pa, n_pb);
  //show((long *)RSTRING(a_matrix)->ptr, n_pa, n_pa);

  result = matchN(num_adj, point, (long *)RSTRING(a_matrix)->ptr, mm, n_pb, n_pa);

  if(result == 1){//?
    mapping = rb_ary_new();
    //printf("n_words : %d n_pa : %d n_pb : %d  n_words * n_pa * n_pa : %d", n_words, n_pa, n_pb, n_words * n_pa * n_pa);
    //show(mm + n_words * n_pb * n_pb, n_pb, n_pa);
  
    for(i = 0 ; i < n_pb ; i++){
      rb_ary_push(mapping, INT2FIX(ntz_m(mm + n_words * n_pb * n_pb + i * n_words, n_pa)));
    }
    return mapping;
  }
  return Qfalse;
}

// DataBase for substructure search

struct dbmdata {
  int  di_size;
};

static VALUE sdb_s_search(VALUE dbname){
  rb_p(dbname);
}

Init_subcomp(){
  VALUE subcomp_cGraph;
  VALUE subcomp_cSubGraphDB;

  subcomp_cGraph = rb_define_module("Graph");
  rb_define_method(subcomp_cGraph, "subcomp_match_by_ullmann", subcomp_match_by_ullmann, 5);

  subcomp_cSubGraphDB = rb_define_class_under(subcomp_cGraph, "SubGraphDB", rb_cObject);

  rb_define_method(subcomp_cSubGraphDB, "open_for_search", sdb_s_search, 0);

  rb_define_singleton_method(subcomp_cSubGraphDB, "show", subcomp_show, 3);
  rb_define_singleton_method(subcomp_cSubGraphDB, "match", subcomp_match_by_ullmann, 5);
}
