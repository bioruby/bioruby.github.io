# $Id: test_sssr.rb 65 2005-10-25 17:17:36Z tanaka $

require 'chem/utils/sssr'

require 'test/all'
require 'test/ctab_test'

class SssrTest < Test::Unit::TestCase

  def setup
  end

  def test_coronen
    coronen = Chem.open_mol($data_dir + '/A_21/coronen.mol')
    coronen.find_sssr
  end

end
