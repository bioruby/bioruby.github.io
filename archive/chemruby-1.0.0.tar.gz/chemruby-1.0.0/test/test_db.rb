
class DBTest < Test::Unit::TestCase

  # Entry finder
  def test_false
#    Chem.find("")
#    assert(false)
  end

end

