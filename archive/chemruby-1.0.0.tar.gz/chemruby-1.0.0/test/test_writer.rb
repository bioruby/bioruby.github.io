# $Id: test_writer.rb 65 2005-10-25 17:17:36Z tanaka $

require 'test/all'

class WriterTest < Test::Unit::TestCase

  def test_undefined_writer
    assert(true)
#     mol = Chem.parse_smiles("CCCC")
#     assert_raise(mol.to_hoge)
  end

end
