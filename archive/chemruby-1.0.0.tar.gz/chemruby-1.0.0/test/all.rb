# $Id: all.rb 61 2005-10-12 09:17:39Z tanaka $

require 'test/unit'
require 'chem'

$data_dir =  File.join(File.dirname(File.expand_path(__FILE__)), "/data/")
