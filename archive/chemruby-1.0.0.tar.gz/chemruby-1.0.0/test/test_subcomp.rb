# $Id: test_subcomp.rb 160 2006-02-14 06:49:37Z tanaka $

require 'test/unit'
require 'test/all'

require 'chem'

class SubcompTest < Test::Unit::TestCase

  def setup
    @mol = Chem.open_mol($data_dir + 'hypericin.mol')
  end

#   def test_mol
#     mol = Chem.open_mol($data_dir + 'hypericin.mol')
#     #assert_equal(mol.nodes.length, mol.match_by_ullmann(mol).length)
#   end

#   def test_match_by_atom
#     mol2 = Chem.parse_smiles("CCCBrCC")
#     mol = Chem.parse_smiles("CCBr")
#     assert_equal(mol.nodes.length, mol.match_by_ullmann(mol2).length);
#   end

  def test_search
    @mol.match_by_ullmann(@mol)
  end

#   def test_exhaustive
#     cyclopropane = SMILES("C1CCC1")
#     match = cyclopropane.match_by_ullmann(cyclopropane)
#     assert_equal([0, 1, 2, 3], match)
#     match = cyclopropane.match_exhaustively(cyclopropane)
#   end

end

