# $Id: test_sbdb.rb 135 2006-02-06 05:48:56Z tanaka $

require 'test/all'

require 'chem'
require 'chem/utils/ullmann'

class SBDBTest < Test::Unit::TestCase

  def test_create_db

#     db = GraphDB.new("kegg")
#     mol = Chem.parse_file($data_dir + "cyclohexane.mol")

#     db.insert(mol)

#     db.select(mol)

#     assert(true)

  end

end
