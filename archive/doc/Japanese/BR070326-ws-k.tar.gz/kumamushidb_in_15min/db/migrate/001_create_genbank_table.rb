class CreateGenbankTable < ActiveRecord::Migration
  def self.up
    create_table "genbanks" do |t|
      t.column "entry",         :string
      t.column "bp",            :integer
      t.column "strand",        :string
      t.column "natype",        :string
      t.column "circular",      :string
      t.column "division",      :string
      t.column "date",          :string
      t.column "definition",    :text
      t.column "accession",     :string
      t.column "version",       :string
      t.column "gi",            :string
      t.column "keyword",       :text
      t.column "source",        :text
      t.column "organism",      :text
      t.column "taxonomy",      :text
      t.column "comment",       :text
      t.column "references",    :text
      t.column "features",      :text
      t.column "naseq",         :text
    end
    add_index :genbanks, :entry
  end

  def self.down
    drop_table "genbanks"
  end
end
