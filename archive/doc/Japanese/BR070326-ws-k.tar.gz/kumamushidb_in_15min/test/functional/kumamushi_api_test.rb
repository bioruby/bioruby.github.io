require File.dirname(__FILE__) + '/../test_helper'
require 'kumamushi_controller'

class KumamushiController; def rescue_action(e) raise e end; end

class KumamushiControllerApiTest < Test::Unit::TestCase
  def setup
    @controller = KumamushiController.new
    @request    = ActionController::TestRequest.new
    @response   = ActionController::TestResponse.new
  end

  def test_list_organisms
    result = invoke :list_organisms
    assert_equal nil, result
  end
end
