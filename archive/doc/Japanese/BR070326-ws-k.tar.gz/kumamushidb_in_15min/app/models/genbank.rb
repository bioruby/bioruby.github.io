class Genbank < ActiveRecord::Base
end
