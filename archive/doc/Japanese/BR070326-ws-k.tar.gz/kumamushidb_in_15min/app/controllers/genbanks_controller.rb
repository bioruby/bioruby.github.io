class GenbanksController < ApplicationController
  def index
    list
    render :action => 'list'
  end

  # GETs should be safe (see http://www.w3.org/2001/tag/doc/whenToUseGet.html)
  verify :method => :post, :only => [ :destroy, :create, :update ],
         :redirect_to => { :action => :list }

  def list
    @genbank_pages, @genbanks = paginate :genbanks, :per_page => 10
  end

  def show
    @genbank = Genbank.find(params[:id])
  end

  def new
    @genbank = Genbank.new
  end

  def create
    @genbank = Genbank.new(params[:genbank])
    if @genbank.save
      flash[:notice] = 'Genbank was successfully created.'
      redirect_to :action => 'list'
    else
      render :action => 'new'
    end
  end

  def edit
    @genbank = Genbank.find(params[:id])
  end

  def update
    @genbank = Genbank.find(params[:id])
    if @genbank.update_attributes(params[:genbank])
      flash[:notice] = 'Genbank was successfully updated.'
      redirect_to :action => 'show', :id => @genbank
    else
      render :action => 'edit'
    end
  end

  def destroy
    Genbank.find(params[:id]).destroy
    redirect_to :action => 'list'
  end
end
