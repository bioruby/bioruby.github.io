class KumamushiController < ApplicationController
  wsdl_service_name 'Kumamushi'

  def list_organisms
    Genbank.find(:all, :group => "organism").map {|x| x.organism}
  end

  def search_entry(keyword)
    list = Genbank.find(:all, :conditions => ["definition LIKE ?", "%#{keyword}%"])
    list.map {|e| "#{e.entry}\t#{e.definition}"}
  end

  def get_entry(entry_id)
    Genbank.find(:first, :conditions => ["entry LIKE ?", entry_id])
  end

  def blast_naseq(query)
    exec_blast('blastn', query)
  end

  def blast_aaseq(query)
    exec_blast('tblastn', query)
  end

  private

  def exec_blast(program, query)
    output = ""
    IO.popen("blastall -p #{program} -d data/kumamushi.fa", "w+") do |io|
      io.sync = true
      io.print query if query
      io.close_write
      output = io.read
    end
    return output
  end

end
