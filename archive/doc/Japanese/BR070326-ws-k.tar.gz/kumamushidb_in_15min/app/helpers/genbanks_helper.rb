module GenbanksHelper
end
