class KumamushiApi < ActionWebService::API::Base
  api_method :list_organisms,
    :returns => [[:string]]

  api_method :search_entry,
  :expects => [{:keyword => :string}],
    :returns => [[:result => :string]]

  api_method :get_entry,
  :expects => [{:entry_id => :string}],
  :returns => [{:result => Genbank}]

  api_method :blast_naseq,
  :expects => [{:query => :string}],
  :returns => [{:result => :string}]

  api_method :blast_aaseq,
  :expects => [{:query => :string}],
  :returns => [{:result => :string}]

end
