#!/usr/bin/env ruby

require 'bio'

Bio::FlatFile.auto(ARGF) do |flat|
  flat.each do |entry|
    header = "#{entry.entry_id} #{entry.definition}"
    puts entry.seq.to_fasta(header, 60) if entry.seq.length > 0
  end
end

