#
# bio.rb - Loading all BioRuby modules
#
#   Copyright (C) 2001 KATAYAMA Toshiaki <k@bioruby.org>
#
#  This library is free software; you can redistribute it and/or
#  modify it under the terms of the GNU Library General Public
#  License as published by the Free Software Foundation; either
#  version 2 of the License, or (at your option) any later version.
#
#  This library is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Library General Public License for more details.
#
#
#    This modlue provides eazy loading of BioRuby products and
#    by using this module, you you don't need to conscious about
#    organization changes in the BioRuby repositiory.
#

### Sequence

require 'sequence.rb'
# require 'data/na.rb'		# included in sequence.rb
# require 'data/aa.rb'		# included in sequence.rb
# require 'data/codontable.rb'	# included in sequence.rb

### Interfaces

require 'dbget.rb'

### DB parsers

#require 'db/dbcommon.rb'	# not used

# GenBank
require 'db/genbank.rb'
require 'db/gblocation.rb'

# KEGG
require 'db/genes.rb'
#require 'db/enzyme.rb'

# Prosite
require 'db/prosite.rb'

### misc utils

require 'util/fold.rb'


