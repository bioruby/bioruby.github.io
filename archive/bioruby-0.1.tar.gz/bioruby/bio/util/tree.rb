#
# bio/util/tree.rb - Hierarchical data structure object
#
#   Copyright (C) 2001 Mitsuteru Nakao <n@bioruby.org>
#
#  This library is free software; you can redistribute it and/or
#  modify it under the terms of the GNU Library General Public
#  License as published by the Free Software Foundation; either
#  version 2 of the License, or (at your option) any later version.
#
#  This library is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Library General Public License for more details.

=begin

= bio/util/tree.rb - hierarchical data structure objeact

Copyright (C) 2001 Mitsuteru Nakao <n@bioruby.org>

This file is a part of the BioRuby project.

== tree.rb version 0.0.1 features

  t=Tree.new
  t.addNode(name,value,attr)
  t.children[0].addNode(name,value,attr)

  t.inorder(t.traversal)
  p t.traversal

== class Node

=end
class Node
  ROOT=0;  NODE=1;
  def initialize (t=ROOT,n=nil,v=nil,p=nil,c=[],a=nil)
    @node_type=t;   # 
    @node_name=n;   # 
    @node_value=v;  # 
    @parent=p;      # Pointer to the parent node
    @children=c;    # Pointer Array for child nodes
    @attribute=a    # gomi ?
  end
  attr_accessor :node_type,:node_name,:node_value,:parent,
    :children,:attribute

=begin

=== Class Methods

  --- Node#to_s

return the string representation of the node

=end

  def to_s
    "\#<Node: @node_type=\'#{@node_type.inspect}\' @node_name=\'#{@node_name.inspect}\' @node_value=\'#{@node_value.inspect}\' @parent=\'#{@parent.inspect}\' @chlidren=\'#{@children.inspect}\' @attribute=\'#{@attribute.inspect}\'>"
  end

=begin  



=== Node interfaces

  --- Node#node(name)

return the Node by name

=end

  def node(name) 
    self.children.each do |c|
      return c if c.node_name == name
    end
    raise "No such node \'#{name}\'"
  end

=begin

  --- Node#addNode(name,value,attribute)

Set a new Node

=end
  def addNode (name=nil,value=nil,attribute=nil)
    self.children.push(Node.new(NODE,name,value,self,[],attribute))
  end;  
=begin

  --- Node#appendNode

Alias to Node#addNode

=end

  alias appendNode addNode
  def delNode raise; "Not yet Implement"; end

=begin

  --- Node#swapChildNodes!(node1,node2)

Swap the node1 and node2

=end

  def swapChildNodes!(node1,node2)    # children[n] <=> children[m]
    raise "No such node" if node1 == nil or node2 == nil
    for i in (0...self.children.length) 
      node1_i = i if self.children[i] == node1
      node2_i = i if self.children[i] == node2
    end
    self.children[node1_i] = node2
    self.children[node2_i] = node1
  end 
  alias swapNodes! swapChildNodes!
=begin
  --- Node#swapNodes!

Alias to Node#swapChildNodes!

=end


=begin  

== Tree traversal

  --- Tree#preorder(Tree.traversal) (^_^;;

Set the preorder traversal route of the tree to Tree.traversal

=end
  def preorder(list)
    list.push(self.node_name)
    self.children.each do |c|
      c.preorder(list)
    end
    list
  end
=begin

  --- Tree#inorder(Tree.traversal) (^_^;;  

Set the inorder traversal route of the tree to Tree.traversal

=end
  def inorder(list)
    if self.children.length==0
      list.push(self.node_name)
    else
      self.children[0].inorder(list) 
      list.push(self.node_name)
      self.children[1...self.children.length].each do |c|
	c.inorder(list)
      end
    end
    list 
  end
=begin

  --- Tree#postorder(Tree.traversal) (^_^;;  

Set the postorder traversal route of the tree to Tree.traversal

=end
  def postorder(list)
    self.children.each do |c|
      c.postorder(list)
    end
    list.push(self.node_name)
    list
  end

end

=begin


== class Tree<Node
    
=end

class Tree<Node
  def initialize (n=nil,v=nil,p=nil,c=[],a=nil)
    @node_type=ROOT;   # (0=ROOT|1=NODE)
    @node_name=n;      # 
    @node_value=v;     #
    @parent=p;         # Pointer to the parent node
    @children=c;       # Pointer Array for child nodes
    @attribute=a       #
    @traversal=[]
  end
  attr_accessor :node_type,:node_name,:node_value,:parent,
    :children,:attribute,:traversal
end


=begin

= See also
ruby


=end



