#
# bio/db/gblocation.rb - GenBank location parser
#
#   Copyright (C) 2001 KATAYAMA Toshiaki <k@bioruby.org>
#
#  This library is free software; you can redistribute it and/or
#  modify it under the terms of the GNU Library General Public
#  License as published by the Free Software Foundation; either
#  version 2 of the License, or (at your option) any later version.
#
#  This library is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Library General Public License for more details.
#

class NAseq

  # list up Location objects as a result of parsing
  def locations(position)
    return gbl_parse(position)
  end


  # splicing DNA sequence and join using Location list
  def splicing(position)
    mRNA = NAseq.new('')				# spliced sequence
    locations(position).each do |location|
      mRNA << location.seq if location.seq
    end
    return mRNA
  end


  # Location receives sequence and location and returns in hash
  #  * sequence must be a NAseq object
  #  * location can be 'ID:' + ('n' or 'n..m' or 'n^m' or "seq") with < or >
  class Location

    def initialize(sequence, location)

      @location = {}

      if location =~ /:/				# (G) ID:location
        id, location = location.split(':')
      else
        id = nil
      end

      lt = true if location =~ /</			# (I) <,>
      gt = true if location =~ />/

      case location
      when /^[<>]?(\d+)$/				# (A, I) n
        s = e = $1.to_i
      when /^<?(\d+)\.\.>?(\d+)$/			# (B, I) n..m
        s = $1.to_i
        e = $2.to_i
        if e - s < 0
          raise "Error  invalid range : #{location}"
        end
      when /^<?(\d+)\^>?(\d+)$/				# (C, I) n^m
        s = $1.to_i
        e = $2.to_i
        if e - s != 1
          raise "Error  invalid range : #{location}"
        end
      when /^"?([ATGCatgc]+)"?$/			# (H) literal sequence
        sequence = NAseq.new($1)
        s = e = nil
      else
        raise "Error  unknown format : #{location}"
      end

      if s and e
        sequence = NAseq.new(sequence[s-1..e-1])
      end

      @location['id']		= id			# external link
      @location['start']	= s			# start base
      @location['end']		= e			# end base
      @location['strand']	= 1			# complement?
      @location['sequence']	= sequence		# literal sequence
      @location['lt']		= lt			# contains '<'
      @location['gt']		= gt			# contains '>'
    end

    # to complement sequence from outside
    def complement
      @location['strand']	*= -1
      @location['sequence']	= @location['sequence'].complement
      self						# return Location obj
    end

    # to replace sequence from outside
    def replace(seq)
      @location['sequence']	= NAseq.new(str)
      self						# return Location obj
    end

    # general method to obtain instance variable
    def get(key = 'sequence')
      @location[key]
    end

    # returns a link to the external entry as GenBank ID
    def id
      @location['id']
    end

    # returns a start position of the location
    def s
      @location['start']
    end

    # returns a end position of the location
    def e
      @location['end']
    end

    # returns a strand direction of the location as 1 or -1 (complement)
    def str
      @location['strand']
    end
    alias strand str

    # returns a sequence at the location
    def seq
      @location['sequence']
    end
    alias sequence seq

  end


  private


  # call real parser and returns Location list
  def gbl_parse(position)
    position  = gbl_pos2pos(position) # preprocessing
    locations = gbl_pos2loc(position) # create array of Location
    return locations
  end


  # preprocessing to clean up position notation
  def gbl_pos2pos(position)
    # sometimes position contains white spaces...
    position.gsub!(/\s+/, '')

    # select one base					# (D) n.m
    #               ..         n          m           :
    #     <match>   $1       ( $2         $3       not   )
    position.gsub!(/(\.{2})?\(?([<>\d]+)\.([<>\d]+)(?!:)\)?/) do |match|
      if $1
        $1 + $3			# ..(n.m)  => ..m
      else
        $2			# (?n.m)?  => n
      end
    end

    # select the 1st location				# (E) one-of()
    #     <match>   one-of ($1     ,     )
    position.gsub!(/one-of\(([^,]+)[^)]+\)/, '\1')

    # substitute order(), group() by join()		# (F) group(), order()
    position.gsub!(/(order|group)/, 'join')

    return position
  end


  # parse position notation and create Location objects
  def gbl_pos2loc(position)
    ary = []

    pos = position

    case position

    when /^join\((.*)\)$/				# (F) join()
      pos =      $1

      pos_list = []
      s = 0			# stack counter
      t = ''			# temporary pos

      pos.split(',').each do |p|
        case p
        when /\(/
          s += 1
          t << p
          next
        when /\)/
          s -= 1
          if s == 0
            pos_list.push(t)
          else
            t << p
            next
          end
        else
          if s == 0
            pos_list.push(p)
          else
            t << p
            next
          end
        end
      end

      pos_list.each do |pos|
        ary << gbl_pos2loc(pos)
      end

    when /^complement\((.*)\)$/				# (J) complement()
      pos =            $1
      gbl_pos2loc(pos).reverse_each do |loc|
        ary << loc.complement
      end

    when /^replace\(([^,]+),"?([^"]*)"?\)/		# (K) replace()
      pos, str =    $1,       $2
      ary << gbl_pos2loc(pos).first.replace(str)

    else						# (A, B, C, G, H, I)

      ary << Location.new(self,pos)

    end

    return ary.flatten
  end

end


=begin

== rules

# genbank/gbrel.txt:
#
#     3.4.12.2 Feature Location
#
#       The second column of the feature descriptor line designates the
#     location of the feature in the sequence. The location descriptor
#     begins at position 22. Several conventions are used to indicate
#     sequence location.
#
#       Base numbers in location descriptors refer to numbering in the entry,
#     which is not necessarily the same as the numbering scheme used in the
#     published report. The first base in the presented sequence is numbered
#     base 1. Sequences are presented in the 5 to 3 direction.
#
#     Location descriptors can be one of the following:
#
# (A) 1. A single base;
#
# (B) 2. A contiguous span of bases;
#
# (C) 3. A site between two bases;
#
# (D) 4. A single base chosen from a range of bases;
#
# (E) 5. A single base chosen from among two or more specified bases;
#
# (F) 6. A joining of sequence spans;
#
# (G) 7. A reference to an entry other than the one to which the feature
#	belongs (i.e., a remote entry), followed by a location descriptor
#	referring to the remote sequence;
#
# (H) 8. A literal sequence (a string of bases enclosed in quotation marks).
#
#
# (C)   A site between two residues, such as an endonuclease cleavage site, is
#     indicated by listing the two bases separated by a carat (e.g., 23^24).
#
# (D)   A single residue chosen from a range of residues is indicated by the
#     number of the first and last bases in the range separated by a single
#     period (e.g., 23.79). The symbols < and > indicate that the end point
# (I) of the range is beyond the specified base number.
#
# (B)   A contiguous span of bases is indicated by the number of the first and
#     last bases in the range separated by two periods (e.g., 23..79). The
# (I) symbols < and > indicate that the end point of the range is beyond the
#     specified base number. Starting and ending positions can be indicated
#     by base number or by one of the operators described below.
#
#       Operators are prefixes that specify what must be done to the indicated
#     sequence to locate the feature. The following are the operators
#     available, along with their most common format and a description.
#
# (J) complement (location): The feature is complementary to the location
#     indicated. Complementary strands are read 5 to 3.
#
# (F) join (location, location, .. location): The indicated elements should
#     be placed end to end to form one contiguous sequence.
#
# (F) order (location, location, .. location): The elements are found in the
#     specified order in the 5 to 3 direction, but nothing is implied about
#     the rationality of joining them.
#
# (F) group (location, location, .. location): The elements are related and
#     should be grouped together, but no order is implied.
#
# (E) one-of (location, location, .. location): The element can be any one,
#     but only one, of the items listed.
#

== classification

(A) Location n

(B) Location n..m

(C) Location n^m

(D) (n.m)		=> Location n

(E) one-of(n,m,..)	=> Location n
    one-of(n..m,..)	=> Location n..m

(F) order(loc,loc,..)	=> join(loc, loc,..)
    group(loc,loc,..)	=> join(loc, loc,..)
    join(loc,loc,..)	=> Sequence

(G) ID:loc		=> Location with ID

(H) "atgc"		=> Location only with Sequence

(I) <n			=> Location n with lt flag
    >n			=> Location n with gt flag
    <n..m		=> Location n..m with lt flag
    n..>m		=> Location n..m with gt flag
    <n..>m		=> Location n..m with lt, gt flag

(J) complement(loc)	=> Sequence

(K) replace(loc, str)	=> Location with replacement Sequence


== samples

(C) n^m

[AB015179]	754^755
[AF179299]	complement(53^54)
[CELXOL1ES]	replace(4480^4481,"")
[ECOUW87]	replace(4792^4793,"a")
[APLPCII]	replace(1905^1906,"acaaagacaccgccctacgcc")

(D) (n.m)

[HACSODA]	157..(800.806)
[HALSODB]	(67.68)..(699.703)
[AP001918]	(45934.45974)..46135
[BACSPOJ]	<180..(731.761)
[BBU17998]	(88.89)..>1122
[ECHTGA]	complement((1700.1708)..(1715.1721))
[ECPAP17]	complement(<22..(255.275))
[LPATOVGNS]	complement((64.74)..1525)
[PIP404CG]	join((8298.8300)..10206,1..855)
[BOVMHDQBY4]	join(M30006.1:(392.467)..575,M30005.1:415..681,M30004.1:129..410,M30004.1:907..1017,521..534)
[HUMMIC2A]	replace((651.655)..(651.655),"")
[HUMSOD102]	order(L44135.1:(454.445)..>538,<1..181)

(E) one-of

[ECU17136]	one-of(898,900)..983
[CELCYT1A]	one-of(5971..6308,5971..6309)
[DMU17742]	8050..one-of(10731,10758,10905,11242)
[PFU27807]	one-of(623,627,632)..one-of(628,633,637)
[BTBAINH1]	one-of(845,953,963,1078,1104)..1354
[ATU39449]	join(one-of(969..1094,970..1094,995..1094,1018..1094),1518..1587,1726..2119,2220..2833,2945..3215)

(F) join, order, group

[AB037374S2]	join(AB037374.1:1..177,1..807)
[AP000001]	join(complement(1..61),complement(AP000007.1:252907..253505))
[ASNOS11]	join(AF130124.1:<2563..2964,AF130125.1:21..157,AF130126.1:12..174,AF130127.1:21..112,AF130128.1:21..162,AF130128.1:281..595,AF130128.1:661..842,AF130128.1:916..1030,AF130129.1:21..115,AF130130.1:21..165,AF130131.1:21..125,AF130132.1:21..428,AF130132.1:492..746,AF130133.1:21..168,AF130133.1:232..401,AF130133.1:475..906,AF130133.1:970..1107,AF130133.1:1176..1367,21..>128)

[AARPOB2]	order(AF194507.1:<1..510,1..>871)
[AF006691]	order(912..1918,20410..21416)
[AF024666]	order(complement(18919..19224),complement(13965..14892))
[AF264948]	order(27066..27076,27089..27099,27283..27314,27330..27352)
[D63363]	order(3..26,complement(964..987))
[ECOCURLI2]	order(complement(1009..>1260),complement(AF081827.1:<1..177))
[S72388S2]	order(join(S72388.1:757..911,S72388.1:609..1542),1..>139)
[HEYRRE07]	order(complement(1..38),complement(M82666.1:1..140),complement(M82665.1:1..176),complement(M82664.1:1..215),complement(M82663.1:1..185),complement(M82662.1:1..49),complement(M82661.1:1..133))
[COL11A1G34]	order(AF101079.1:558..1307,AF101080.1:1..749,AF101081.1:1..898,AF101082.1:1..486,AF101083.1:1..942,AF101084.1:1..1734,AF101085.1:1..2385,AF101086.1:1..1813,AF101087.1:1..2287,AF101088.1:1..1073,AF101089.1:1..989,AF101090.1:1..5017,AF101091.1:1..3401,AF101092.1:1..1225,AF101093.1:1..1072,AF101094.1:1..989,AF101095.1:1..1669,AF101096.1:1..918,AF101097.1:1..1114,AF101098.1:1..1074,AF101099.1:1..1709,AF101100.1:1..986,AF101101.1:1..1934,AF101102.1:1..1699,AF101103.1:1..940,AF101104.1:1..2330,AF101105.1:1..4467,AF101106.1:1..1876,AF101107.1:1..2465,AF101108.1:1..1150,AF101109.1:1..1170,AF101110.1:1..1158,AF101111.1:1..1193,1..611)

# group found in COMMENT only (GenBank 122.0)
gbpat2.seq:            FT   repeat_region   group(598..606,611..619)
gbpat2.seq:            FT   repeat_region   group(8..16,1457..1464).
gbpat2.seq:            FT   variation       group(t1,t2)
gbpat2.seq:            FT   variation       group(t1,t3)
gbpat2.seq:            FT   variation       group(t1,t2,t3)
gbpat2.seq:            FT   repeat_region   group(11..202,203..394)
gbpri9.seq:COMMENT     Residues reported = 'group(1..2145);'.

(G) ID:location

[AARPOB2]	order(AF194507.1:<1..510,1..>871)
[AF178221S4]	join(AF178221.1:<1..60,AF178222.1:1..63,AF178223.1:1..42,1..>90)
[BOVMHDQBY4]	join(M30006.1:(392.467)..575,M30005.1:415..681,M30004.1:129..410,M30004.1:907..1017,521..534)
[HUMSOD102]	order(L44135.1:(454.445)..>538,<1..181)
[SL16SRRN1]	order(<1..>267,X67092.1:<1..>249,X67093.1:<1..>233)

(I) <, >

[A5U48871]	<1..>318
[AA23SRRNP]	<1..388
[AA23SRRNP]	503..>1010
[AAM5961]	complement(<1..229)
[AAM5961]	complement(5231..>5598)
[AF043934]	join(<1,60..99,161..241,302..370,436..594,676..887,993..1141,1209..1329,1387..1559,1626..1646,1708..>1843)
[BACSPOJ]	<180..(731.761)
[BBU17998]	(88.89)..>1122
[AARPOB2]	order(AF194507.1:<1..510,1..>871)
[SL16SRRN1]	order(<1..>267,X67092.1:<1..>249,X67093.1:<1..>233)

(J) complement

[AF179299]	complement(53^54)	<= hoge insertion site etc.
[AP000001]	join(complement(1..61),complement(AP000007.1:252907..253505))
[AF209868S2]	order(complement(1..>308),complement(AF209868.1:75..336))
[AP000001]	join(complement(1..61),complement(AP000007.1:252907..253505))
[CPPLCG]	complement(<1..(1093.1098))
[D63363]	order(3..26,complement(964..987))
[ECHTGA]	complement((1700.1708)..(1715.1721))
[ECOUXW]	order(complement(1658..1663),complement(1636..1641))
[LPATOVGNS]	complement((64.74)..1525)
[AF129075]	complement(join(71606..71829,75327..75446,76039..76203,76282..76353,76914..77029,77114..77201,77276..77342,78138..78316,79755..79892,81501..81562,81676..81856,82341..82490,84208..84287,85032..85122,88316..88403))
[ZFDYST2]	join(AF137145.1:<1..18,complement(<1..99))

(K) replace

[CSU27710]	replace(64,"A")
[CELXOL1ES]	replace(5256,"t")
[ANICPC]	replace(1..468,"")
[CSU27710]	replace(67..68,"GC")
[CELXOL1ES]	replace(4480^4481,"")	<= ? only one case in GenBank 122.0
[ECOUW87]	replace(4792^4793,"a")
[CEU34893]	replace(1..22,"ggttttaacccagttactcaag")
[APLPCII]	replace(1905^1906,"acaaagacaccgccctacgcc")
[MBDR3S1]	replace(1400..>9281,"")
[HUMMHDPB1F]	replace(complement(36..37),"ttc")
[HUMMIC2A]	replace((651.655)..(651.655),"")
[LEIMDRPGP]	replace(1..1554,"L01572")
[TRBND3]	replace(376..395,"atttgtgtgtggtaatta")
[TRBND3]	replace(376..395,"atttgtgtgggtaatttta")
[TRBND3]	replace(376..395,"attttgttgttgttttgttttgaatta")
[TRBND3]	replace(376..395,"atgtgtggtgaatta")
[TRBND3]	replace(376..395,"atgtgtgtggtaatta")
[TRBND3]	replace(376..395,"gatttgttgtggtaatttta")
[MSU09460]	replace(193,		<= replace(193, "t")
[HUMMAGE12X]	replace(3002..3003,	<= replace(3002..3003, "GC")
[ADR40FIB]	replace(510..520,	<= replace(510..520, "taatcctaccg")
[RATDYIIAAB]	replace(1306..1443,"aagaacatccacggagtcagaactgggctcttcacgccggatttggcgttcgaggccattgtgaaaaagcaggcaatgcaccagcaagctcagttcctacccctgcgtggacctggttatccaggagctaatcagtacagttaggtggtcaagctgaaagagccctgtctgaaa")

=end

