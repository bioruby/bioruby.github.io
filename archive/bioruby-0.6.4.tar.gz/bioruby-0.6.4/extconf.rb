require 'mkmf'
create_makefile("bioruby")
